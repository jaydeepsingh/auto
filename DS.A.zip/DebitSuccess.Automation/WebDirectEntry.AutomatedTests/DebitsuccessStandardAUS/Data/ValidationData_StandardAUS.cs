﻿using System;
using System.Collections.Generic;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardAUS.Data
{
    public static class ValidationData_StandardAUS
    {
        public static List<string> CustomerDetailsTabEmptyFieldsMessages
        {
            get
            {
                return new List<string>
                {
                    "First name or last name is required",
                    "Date of birth is required",
                    "Mailing address is required",
                    "Suburb is required",
                    "Postcode is required",
                    "Email is required",
                    "At least one phone number is required",
                    "Enter a valid phone number",
                    "Emergency contact name is required"
                };
            }
        }

        public static List<string> PaymentPlanTabEmptyFieldsMessages
        {
            get
            {
                return new List<string>
                {
                    "Instalment amount is required.",
                    "Initials are required"
                };
            }
        }

        public static string FirstPaymentDateValidationMessage = "First payment date should be greater than today or less than a year";

        public static BasePaymentPlanModel NegativeAmountFieldsModel = new BasePaymentPlanModel
        {
            PaymentFrequency = PaymentFrequency.WK,
            InstalmentAmount = -100,
            BillingFee = -49,
            FirstPaymentDate = DateTime.Now.AddDays(1).ToString("dd/MM/yyyy"),
            MinimumTermMonths = -12,
            CancellationFee = -149,
            SuspensionFee = -50,
            TerminateAfterMinTerm = false,
            Initials = true,
            TermType = TermType.M,
            SpecialConditions = "Special Condition!!!"
        };

        public static BasePaymentPlanModel InvalidFirstPaymentDateModel = new BasePaymentPlanModel
        {
            PaymentFrequency = PaymentFrequency.WK,
            InstalmentAmount = 100,
            BillingFee = 49,
            MinimumTermMonths = 12,
            CancellationFee = 149,
            SuspensionFee = 50,
            TerminateAfterMinTerm = false,
            Initials = true,
            TermType = TermType.M,
            SpecialConditions = "Special Condition!!!"
        };

        public static List<string> PaymentPlanTabNegativeAmountFieldsMessages
        {
            get
            {
                return new List<string>
                {
                    "Instalment amount is required.",
                    "Minimum term in months must be a valid integer and must be greater than or equal to 0",
                    "Cancellation fee must be a valid amount"
                };
            }
        }
    }
}
