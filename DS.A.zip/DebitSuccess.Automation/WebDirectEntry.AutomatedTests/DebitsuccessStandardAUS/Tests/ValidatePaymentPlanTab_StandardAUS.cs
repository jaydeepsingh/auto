﻿using System.Linq;
using DebitSuccess.Automation.Framework.Fixtures;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardAUS.Data;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;
using WebDirectEntry.AutomatedTests.Shared.Tests;
using Xunit;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardAUS.Tests
{
    [Story(AsA = "As a Web Direct Entry user, ",
            IWant = "I want to be able to see error messages if I fail to fill the payment plan tab",
            SoThat = "I can re-enter the correct information to submit the form")]
    public class ValidatePaymentPlanTab_StandardAUS : SharedTest
    {
        
        public ValidatePaymentPlanTab_StandardAUS(TestClassFixture testClassFixture)
            : base(testClassFixture)
        {
            TemplateName = TemplateNames.StandardAus;
        }
        
        [Fact]
        public void ValidateEmptyPaymentPlanForm()
        {
            
            this.Given(x => x.GivenISelectDirectEntryTemplate(TemplateName, LoginData.AtMasterUser), string.Format("Given I am logged in as {0} on the direct entry", LoginData.AtMasterUser))
                .When(x => x.WhenIFillNothingInPaymentPlanPage(TemplateBaseData.DirectEntryTestcaseBaseData))
                .Then(x => x.ThenIShouldSeeValidateErrorMessagesOnPage(ValidationData_StandardAUS.PaymentPlanTabEmptyFieldsMessages, 
                    PaymentPlanTab.ErrorMessageComponent.ValidationErrorMessages))
                .BDDfy();
        }

        [Fact]
        public void ValidateFirstPaymentDate()
        {
            string firstPaymentDate = default(string);
            string errorMessage = default(string);
           
            this.Given(x => x.GivenISelectDirectEntryTemplate(TemplateName, LoginData.AtMasterUser), string.Format("Given I am logged in as {0} on the direct entry", LoginData.AtMasterUser))
                .When(x => x.WhenIFillWrongFirstPaymentDateInPaymentPlanTab(firstPaymentDate, TemplateBaseData.DirectEntryTestcaseBaseData))
                .Then(x => x.ThenIShouldSeeTheValidateErrorMessageOnPage(errorMessage, PaymentPlanTab.ErrorMessageComponent.ValidationErrorMessages))
                .WithExamples(new ExampleTable("First Payment Date", "Error Message")
                {
                    {"01/01/2016", ValidationData_StandardAUS.FirstPaymentDateValidationMessage},
                    {"01/01/2020", ValidationData_StandardAUS.FirstPaymentDateValidationMessage}
                })
                .BDDfy();
        }

        [Fact]
        public void ValidateNegativeAmountOnMoneyFields()
        {
            string firstPaymentDate = default(string);
            string errorMessage = default(string);
            
            this.Given(x => x.GivenISelectDirectEntryTemplate(TemplateName, LoginData.AtMasterUser), string.Format("Given I am logged in as {0} on the direct entry", LoginData.AtMasterUser))
                .When(x => x.WhenIEnterNegativeAmountInAllMoneyFields(TemplateBaseData.DirectEntryTestcaseBaseData))
                .Then(x => x.ThenIShouldSeeValidateErrorMessagesOnPage(ValidationData_StandardAUS.PaymentPlanTabNegativeAmountFieldsMessages, PaymentPlanTab.ErrorMessageComponent.ValidationErrorMessages))
                .BDDfy();
        }

        public void WhenIFillNothingInPaymentPlanPage(BaseTemplateDetailsModel model)
        {
            PaymentPlanTab = TemplateDetailsPage.ContractTab
                .UpdateContractTab(model.ContractModel).Next<BaseCustomerDetailsTab>()
                .UpdateCustomerDetailsTab(model.CustomerDetailsModel).Next<BasePaymentPlanTab>()
                .Next<BasePaymentPlanTab>(); 
        }

        public void WhenIFillWrongFirstPaymentDateInPaymentPlanTab(string firstPaymentDate, BaseTemplateDetailsModel model)
        {
            var paymentPlanModel = ValidationData_StandardAUS.InvalidFirstPaymentDateModel;
            paymentPlanModel.FirstPaymentDate = firstPaymentDate;
            PaymentPlanTab = TemplateDetailsPage.ContractTab
                .UpdateContractTab(model.ContractModel).Next<BaseCustomerDetailsTab>()
                .UpdateCustomerDetailsTab(model.CustomerDetailsModel).Next<BasePaymentPlanTab>()
                .UpdatePaymentPlanTab(paymentPlanModel)
                .Initial()
                .Next<BasePaymentPlanTab>();
        }

        public void WhenIEnterNegativeAmountInAllMoneyFields(BaseTemplateDetailsModel model)
        {
            PaymentPlanTab = TemplateDetailsPage.ContractTab
                .UpdateContractTab(model.ContractModel).Next<BaseCustomerDetailsTab>()
                .UpdateCustomerDetailsTab(model.CustomerDetailsModel).Next<BasePaymentPlanTab>()
                .UpdatePaymentPlanTab(ValidationData_StandardAUS.NegativeAmountFieldsModel)
                .Initial()
                .Next<BasePaymentPlanTab>();
        }
    }
}
