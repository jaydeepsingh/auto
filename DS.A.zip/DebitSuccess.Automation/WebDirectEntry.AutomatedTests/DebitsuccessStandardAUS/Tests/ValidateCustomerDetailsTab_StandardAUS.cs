﻿using DebitSuccess.Automation.Framework.Fixtures;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardAUS.Data;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;
using WebDirectEntry.AutomatedTests.Shared.Tests;
using Xunit;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardAUS.Tests
{
    [Story(AsA = "As a Web Direct Entry user, ",
        IWant = "I want to be able to see error messages if I failed to fill customer details ",
        SoThat = "I can re-enter the correct information to submit the form")]
    public class ValidateCustomerDetailsTab_StandardAUS : SharedTest
    {
        public ValidateCustomerDetailsTab_StandardAUS(TestClassFixture testClassFixture)
            : base(testClassFixture)
        {
            TemplateName = "Debitsuccess Standard AUS";
        }

        [Fact]
        public void ValidateEmptyCustomDetailsForm()
        {
            
            this.Given(x => x.GivenISelectDirectEntryTemplate(TemplateName, LoginData.AtMasterUser), string.Format("Given I am logged in as {0} on the direct entry", LoginData.AtMasterUser))
                .When(x => x.WhenIFillNothingInCustomerDetailsPage(TemplateBaseData.DirectEntryTestcaseBaseData))
                .Then(x => x.ThenIShouldSeeValidateErrorMessagesOnPage(ValidationData_StandardAUS.CustomerDetailsTabEmptyFieldsMessages, 
                    CustomerDetailsTab.ErrorMessageComponent.ValidationErrorMessages))
                .BDDfy();
        }

        public virtual void WhenIFillNothingInCustomerDetailsPage(BaseTemplateDetailsModel model)
        {
            CustomerDetailsTab = TemplateDetailsPage.ContractTab
                .UpdateContractTab(model.ContractModel)
                .Next<BaseCustomerDetailsTab>()
                .Next<BaseCustomerDetailsTab>(); //directly click next
        }


    }
}
