﻿using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardAUS.Pages
{
    public class PaymentPlanTab_StandardAUS : BasePaymentPlanTab
    {
    }
}
