﻿using DebitSuccess.Automation.Framework.Fixtures;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Data;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Models;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Pages;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ_Offline.Pages;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;
using WebDirectEntry.AutomatedTests.Shared.Tests;
using Xunit;
namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ_Offline.Tests
{
    [Story(AsA = "As a Web Direct Entry user, ",
        IWant = "I want to be able to submit a 'Debitsuccess Standard NZ- Offline template' via Web Direct Entry ",
        SoThat = "I can sign up a standard NZ customer")]
    public class Submit_StandardNZ_Offline : SharedTest
    {
        public Submit_StandardNZ_Offline(TestClassFixture testClassFixture)
            : base(testClassFixture)
        {
            TemplateName = TemplateNames.DebitsuccessStandardNZOffline;
        }

        [Fact]
        public void SubmitCustomerBasicFlow()
        {
            string customerId = default(string);
            CustomerType customerType = default(CustomerType);
            PaymentFrequency paymentFrequency = default(PaymentFrequency);
            int Installmentamount = default(int);
            bool firstOneOffPayment = default(bool);
            bool secondOneOffPayment = default(bool);
            PaymentType paymentType = default(PaymentType);
            TermType termType = default(TermType);
            string SpecialCondition = default(string);
            this.Given(x => x.GivenISelectDirectEntryTemplate(TemplateName, LoginData.AtMasterUser),
                string.Format("Given I am logged in as {0} on the direct entry", LoginData.AtMasterUser))
                .When(x => x.WhenIUpdateDirectEntryTemplate(customerId, customerType, paymentFrequency, Installmentamount, firstOneOffPayment, secondOneOffPayment, termType, paymentType, SpecialCondition, StandardNZTemplateData.BaseStandardNZData),
                    "When I sign up a customer thorugh Web Direct Entry Standard NZ template")
                .Then(x => x.ThenIShouldBeAbleToSeeSuccessfulMessage())
                .WithExamples(new ExampleTable("Customer ID", "Customer Type", "Payment Frequency", "Installment amount", "First One Off Payment", "Second One Off Payment", "Term Type", "Payment Type", "Special Condition")
                {

                    {"Cus Id 111",CustomerType.STD, PaymentFrequency.FN,90,true,false,TermType.P,PaymentType.BA,""},
                    {"",CustomerType.STD,PaymentFrequency.WK,110,true,true,TermType.M,PaymentType.CC,"Special Condition Text"},
                    {"",CustomerType.STD, PaymentFrequency.MN,105,false,false,TermType.M,PaymentType.BA,"Special Condition Text"},
                    {"",CustomerType.STD, PaymentFrequency.FW,200,true,false,TermType.M,PaymentType.BA,""},
                    {"",CustomerType.TF, PaymentFrequency.WK,50,true,false,TermType.P,PaymentType.CC,"Special Condition Text"},


                 })
                .BDDfy();
        }

        public virtual void WhenIUpdateDirectEntryTemplate(string customerid, CustomerType customertype, PaymentFrequency payFrequency, int installmentamount, bool firstOneOffPayment, bool secondOneOffPayment, TermType termType, PaymentType paymentType, string SpecialCondition, StandardNZTemplateDetailModel model)
        {
            model.ContractModel.BusinessId = customerid;
            model.ContractModel.CustomerType = customertype;
            model.PaymentPlanModel.PaymentFrequency = payFrequency;
            model.PaymentPlanModel.InstalmentAmount = installmentamount;
            model.PaymentPlanModel.FirstOneOff = firstOneOffPayment;
            model.PaymentPlanModel.SecondOneOff = secondOneOffPayment;
            model.PaymentPlanModel.TermType = termType;
            model.PaymentModel.PaymentType = paymentType;
            model.PaymentPlanModel.SpecialConditions = SpecialCondition;


            ConfirmationPage = TemplateDetailsPage.ContractTabStandardNz
                .UpdateContractTab(model.ContractModel).Next<CustomerDetailsTab_StandardNZ>()
                .UpdateCustomerDetailsTab(model.CustomerDetailsModel).Next<PaymentPlanTab_StandardNZ_Offline>()
                .UpdatePaymentPlanTab(model.PaymentPlanModel)
                .Initial().Next<PaymentTab_StandardNZ>()
                .UpdatePaymentTab(model.PaymentModel).Next<SignaturesTab_StandardNZ>()
                .Submit();

            ConfirmationPage.ViewCustomerDetails();
            ConfirmationPage.ReadDebitSuccessId();
        }
    }
}
 