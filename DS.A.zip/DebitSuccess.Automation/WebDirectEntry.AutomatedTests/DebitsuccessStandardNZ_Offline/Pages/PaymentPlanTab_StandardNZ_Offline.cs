﻿using Castle.DynamicProxy.Generators.Emitters.SimpleAST;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Models;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ_Offline.Pages
{
    public class PaymentPlanTab_StandardNZ_Offline : BasePaymentPlanTab
    {
        public override BasePaymentPlanTab UpdatePaymentPlanTab(BasePaymentPlanModel model)
        {
            var StandardNZModel = (StandardNZPaymentPlanModel)model;

            if (model.InstalmentAmount > 0)
            {
                InstalmentAmount = model.InstalmentAmount.ToString();
            }
            else
            {
                InstalmentAmount = "";
            }


            Find.SendDirectEntryDataToForm(new
            {

                model.TermType,
                model.FirstPaymentDate,
                model.TerminateAfterMinTerm,
                model.PaymentFrequency,
                model.CancellationFee


            });
            //Below given element is having textarea as the tagname so hardcoded the uniquekey to find the element
            IWebElement element = Find.Element(By.CssSelector("textarea[key='SpecialConditions']"));
            element.SendKeys(model.SpecialConditions.ToString());

            if ((model.TermType).ToString() == "P")
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.MinimumTermPayments
                });
            }
            else
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.MinimumTermMonths
                });
            }
            if (model.FirstOneOff)
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.FirstOneOff,
                    model.AddOneOffPaymentOne.FirstOneOffAmount,
                    model.AddOneOffPaymentOne.FirstOneOffDesc,
                    model.AddOneOffPaymentOne.FirstOneOffDate
                });
            }
            if (model.SecondOneOff)
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.SecondOneOff,
                    model.AddOneOffPaymentTwo.SecondOneOffAmount,
                    model.AddOneOffPaymentTwo.SecondOneOffDesc,
                    model.AddOneOffPaymentTwo.SecondOneOffDate
                });
            }

            if (model.InstalmentAmount > 0) //can't fill some fields if instalment amount is not filled
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.FirstPaymentDate,
                    model.BillingFee
                });
            }
            Find.TakeTestScreenshot("Payment Plan Tab");
            return this;
        }


        public override BasePaymentPlanTab Initial()
        {
            
            Execute.Script("$('Input[Key=AcceptFacProvidedTandCs]').removeAttr('disabled')");
            Find.Element(By.CssSelector("Input[Key=AcceptFacProvidedTandCs]")).Click();
            return this;
        }
    }
}

