﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DebitSuccess.Automation.Framework.Fixtures;
using DebitSuccess.Automation.Framework.TestSettings;
using FluentAssertions;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.Genesis.Data;
using WebDirectEntry.AutomatedTests.Genesis.Models;
using WebDirectEntry.AutomatedTests.Genesis.Pages;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Pages;
using WebDirectEntry.AutomatedTests.Shared.Tests;
using Xunit;

namespace WebDirectEntry.AutomatedTests.GenesisWA.Tests
{
    [Story(AsA = "As a Web Direct Entry user, ",
        IWant = "I want to Select the form with Paid in Full option' ",
        SoThat = "I can submit the GenesisWA Template")]
    public class Submit_PaidinFull_GenesisWA : SharedTest
    {
        public Submit_PaidinFull_GenesisWA(TestClassFixture testClassFixture)
            : base(testClassFixture)
        {
            TemplateName = TemplateNames.GenesisWa;
        }

        [Fact]
        public void SubmitGenesisWAForm_PaidinFull()
        {
            string BusinessAccountname = "DST1";

            this.Given(x => x.GivenDefaultBusinessSettingsOnWde(LoginData.AtMasterUser, BusinessAccountname, TemplateName), string.Format("Given I am logged in as {0} on the direct entry and change business settings", LoginData.AtMasterUser))
                .When(x => x.WhenPaidinFull(GenesisTemplateData.BaseGenesisData))
                .Then(x => x.ThenIShouldBeAbleToSeeSuccessfulMessage())
                .BDDfy();
        }
        public virtual void WhenPaidinFull(GenesisTemplateDetailsModel model)
        {
           
           
            ConfirmationPage = TemplateDetailsPage.ContractTab
                .UpdateContractTab(model.ContractModel).Next<CustomerDetailsTab_Genesis>()
                .UpdateCustomerDetailsTab(model.CustomerDetailsModel).Next<PaymentPlanTab_Genesis>()
                .UpdatePaymentPlanTabPaidInFull(model.PaymentInfullPlanModel)
                .Next<ParqTab_Genesis>()
                .UpdateParqTab(model.ParqModel).Next<BaseSignaturesTab>()
                .SignAll()
                .Submit();


        }
    }
}
