﻿using DebitSuccess.Automation.Framework.Fixtures;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;
using WebDirectEntry.AutomatedTests.Shared.Tests;
using Xunit;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardAUS_QLD_WA.Tests
{
    [Story(AsA = "As a Web Direct Entry user, ",
        IWant = "I want to be able to submit a 'Debitsuccess Standard AUS - QLD WA template' via Web Direct Entry ",
        SoThat = "I can sign up a Standard AUS - QLD and WA customer")]
    public class RegisterTests_StandardAUS_QLD_WA : SharedTest
    {
        public RegisterTests_StandardAUS_QLD_WA(TestClassFixture testClassFixture) : base(testClassFixture)
        {
            TemplateName = TemplateNames.StandardAusQldAndWa;
        }

        [Fact]
        public void RegisterCustomerBasicFlow()
        {
           

            this.Given(x => x.GivenISelectDirectEntryTemplate(TemplateName, LoginData.AtMasterUser),
                string.Format("Given I am logged in as {0} on the direct entry", LoginData.AtMasterUser))
                .When(x => x.WhenIUpdateDirectEntryTemplate(TemplateBaseData.DirectEntryTestcaseBaseData),
                    "When I sign up a customer thorugh Web Direct Entry Standard AUS QLD WA template")
                .Then(x => x.ThenIShouldBeAbleToSeeSuccessfulMessage())
                
                .BDDfy();
        }

        public virtual void WhenIUpdateDirectEntryTemplate( BaseTemplateDetailsModel model)
        {
            

            ConfirmationPage = TemplateDetailsPage.ContractTab
                .UpdateContractTab(model.ContractModel).Next<BaseCustomerDetailsTab>()
                .UpdateCustomerDetailsTab(model.CustomerDetailsModel).Next<BasePaymentPlanTab>()
                .UpdatePaymentPlanTab(model.PaymentPlanModel)
                .Initial().Next<BasePaymentTab>()
                .UpdatePaymentTab(model.PaymentModel).Next<BaseSignaturesTab>()
                .SignAll()
                .Submit();

            
        }
    }
}