﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DebitSuccess.Automation.Framework.Fixtures;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;
using WebDirectEntry.AutomatedTests.Shared.Tests;
using Xunit;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardAUS_SA.Tests
{
    [Story(AsA = "As a Web Direct Entry user, ",
        IWant = "I want to be able to submit a 'Debitsuccess Standard AUS - SA template' via Web Direct Entry ",
        SoThat = "I can sign up a Standard AUS - SA customer")]
    public class Submit_StandardAUS_SA : SharedTest
    {
        public Submit_StandardAUS_SA(TestClassFixture testClassFixture)
            : base(testClassFixture)
        {
            TemplateName = TemplateNames.StandardAusSa;
        }

        [Fact]
        public void SubmitStandardAussa()
        {
            string customerId = default(string);
            CustomerType customerType = default(CustomerType);
            PaymentFrequency paymentFrequency = default(PaymentFrequency);
            int Installmentamount = default(int);
            bool firstOneOffPayment = default(bool);
            bool secondOneOffPayment = default(bool);
            PaymentType paymentType = default(PaymentType);
            TermType termType = default(TermType);
            string SpecialCondition = default(string);
            this.Given(x => x.GivenISelectDirectEntryTemplate(TemplateName, LoginData.AtMasterUser),
                string.Format("Given I am logged in as {0} on the direct entry", LoginData.AtMasterUser))
                .When(x => x.WhenIUpdateDirectEntryTemplate(customerId, customerType, paymentFrequency, Installmentamount, firstOneOffPayment, secondOneOffPayment, termType, paymentType, SpecialCondition, TemplateBaseData.DirectEntryTestcaseBaseData),
                    "When I sign up a customer thorugh Web Direct Entry Standard AUS SA template")
                .Then(x => x.ThenIShouldBeAbleToSeeSuccessfulMessage())
                .WithExamples(new ExampleTable("Customer ID", "Customer Type", "Payment Frequency", "Installment amount", "First One Off Payment", "Second One Off Payment", "Term Type", "Payment Type","Special Condition")

                {
                    {"Cus Id 111",CustomerType.STD, PaymentFrequency.FN,0,true,false,TermType.P,PaymentType.BA,""},
                    {"",CustomerType.STD,PaymentFrequency.WK,110,true,true,TermType.M,PaymentType.CC,"Special Condition Text"},
                    {"",CustomerType.STD, PaymentFrequency.MN,105,false,false,TermType.M,PaymentType.BA,"Special Condition Text"},
                    {"",CustomerType.STD, PaymentFrequency.FW,0,true,false,TermType.M,PaymentType.BA,""},
                    {"",CustomerType.STD, PaymentFrequency.QT,105,false,false,TermType.M,PaymentType.BA,""},
                    {"",CustomerType.TF, PaymentFrequency.WK,0,true,false,TermType.P,PaymentType.CC,"Special Condition Text"},
                    {"",CustomerType.RE, PaymentFrequency.MN,110,true,true,TermType.P,PaymentType.CC,""},
                    {"",CustomerType.STD,PaymentFrequency.MN,0,true,false,TermType.P,PaymentType.CC,"Special Condition Text"},

                })
                .BDDfy();
        }

        public virtual void WhenIUpdateDirectEntryTemplate(string customerid, CustomerType customertype, PaymentFrequency payFrequency, int installmentamount, bool firstOneOffPayment, bool secondOneOffPayment, TermType termType, PaymentType paymentType,string SpecialCondition, BaseTemplateDetailsModel model)
        {
            model.ContractModel.BusinessId = customerid;
            model.ContractModel.CustomerType = customertype;
            model.PaymentPlanModel.PaymentFrequency = payFrequency;
            model.PaymentPlanModel.InstalmentAmount = installmentamount;
            model.PaymentPlanModel.FirstOneOff = firstOneOffPayment;
            model.PaymentPlanModel.SecondOneOff = secondOneOffPayment;
            model.PaymentPlanModel.TermType = termType;
            model.PaymentModel.PaymentType = paymentType;
            model.PaymentPlanModel.SpecialConditions = SpecialCondition;

            ConfirmationPage = TemplateDetailsPage.ContractTab
                .UpdateContractTab(model.ContractModel).Next<BaseCustomerDetailsTab>()
                .UpdateCustomerDetailsTab(model.CustomerDetailsModel).Next<BasePaymentPlanTab>()
                .UpdatePaymentPlanTab(model.PaymentPlanModel)
                .Initial().Next<BasePaymentTab>()
                .UpdatePaymentTab(model.PaymentModel).Next<BaseSignaturesTab>()
                .SignAll()
                .Submit();

            ConfirmationPage.ViewCustomerDetails();
            ConfirmationPage.ReadDebitSuccessId();
        }

    }
}
