﻿using DebitSuccess.Automation.Framework.Fixtures;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.Genesis.Data;
using WebDirectEntry.AutomatedTests.Genesis.Models;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Tests;
using Xunit;

namespace WebDirectEntry.AutomatedTests.Genesis.Pages
{
    [Story(AsA = "As a Web Direct Entry user, ",
        IWant = "I want to be able to see error messages if I failed to submit a 'Genesis template' ",
        SoThat = "I can re-enter the correct information to submit the form")]
    public class ValidateCustomerDetailsTab_Genesis : SharedTest
    {
        public ValidateCustomerDetailsTab_Genesis(TestClassFixture testClassFixture)
            : base(testClassFixture)
        {
            TemplateName = TemplateNames.Genesis;
        }

        [Fact]
        public void ValidateEmptyCustomDetailsForm()
        {
            
            this.Given(x => x.GivenISelectDirectEntryTemplate(TemplateName, LoginData.AtMasterUser), string.Format("Given I am logged in as {0} on the direct entry", LoginData.AtMasterUser))
                .When(x => x.WhenIFillNothingInCustomerDetailsPage(GenesisTemplateData.BaseGenesisData))
                .Then(x => x.ThenIShouldSeeValidateErrorMessagesOnPage(ValidationData_Genesis.CustomerDetailsTabEmptyFieldsMessages, 
                    CustomerDetailsTab.ErrorMessageComponent.ValidationErrorMessages))
                .BDDfy();
        }

        public virtual void WhenIFillNothingInCustomerDetailsPage(GenesisTemplateDetailsModel model)
        {
            CustomerDetailsTab = TemplateDetailsPage.ContractTab
                .UpdateContractTab(model.ContractModel)
                .Next<CustomerDetailsTab_Genesis>()
                .Next<CustomerDetailsTab_Genesis>();
        }
    }
}
