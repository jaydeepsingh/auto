﻿using System.IO;
using DebitSuccess.Automation.Framework.Fixtures;
using DebitSuccess.Automation.Framework.TestSettings;
using OpenQA.Selenium.Support.Events;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.Genesis.Data;
using WebDirectEntry.AutomatedTests.Genesis.Models;
using WebDirectEntry.AutomatedTests.Genesis.Pages;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;
using WebDirectEntry.AutomatedTests.Shared.Tests;
using Xunit;

namespace WebDirectEntry.AutomatedTests.Genesis.Tests
{
    [Story(AsA = "As a Web Direct Entry user, ",
     IWant = "To select different option in the Genasis Template with Paid not in Full' ",
     SoThat = "I can successfully submit the form for Genesis Template")]

    public class Submit_NotPaidinFull_Genesis : SharedTest
    {
        public Submit_NotPaidinFull_Genesis(TestClassFixture testClassFixture)
            : base(testClassFixture)
        {
            TemplateName = TemplateNames.Genesis;
        }

        [Fact]
        public void SubmitGenesisForm()
        {
            string BusinessAccountname = "DST1";
            string customerId = default(string);
            CustomerType customerType = default(CustomerType);
            PaymentFrequency paymentFrequency = default(PaymentFrequency);
            int Installmentamount = default(int);
            bool firstOneOffPayment = default(bool);
            bool secondOneOffPayment = default(bool);
            PaymentType paymentType = default(PaymentType);
            TermType termType = default(TermType);
            string confirmationMessage = default(string);

           
            this.Given(x => x.GivenDefaultBusinessSettingsOnWde(LoginData.AtMasterUser,BusinessAccountname, TemplateName),
                string.Format("Given I am logged in as {0} on the direct entry and change the Business Settings to Default ", LoginData.AtMasterUser))
                .When(x => x.WhenPaymentTypeSelected(customerId, customerType, paymentFrequency, Installmentamount, firstOneOffPayment, secondOneOffPayment, termType, paymentType, GenesisTemplateData.BaseGenesisData),
                 "When I sign up a customer thorugh Web Direct Entry Genesis template")
                .Then(x => x.ThenIShouldSeeValidateSuccessMessagesOnPage(confirmationMessage, ConfirmationPage.RegistrationSuccessfulMessage()))
                .WithExamples(new ExampleTable("Customer ID", "Customer Type", "Payment Frequency", "Installment amount", "First One Off Payment", "Second One Off Payment", "Term Type", "Payment Type", "Confirmation Message")
                {
                   
                    {"",CustomerType.STD, PaymentFrequency.FN,3,true,false,TermType.P,PaymentType.BA,ValidationData_Genesis.SuccessValidationMessage},
                    {"",CustomerType.STD,PaymentFrequency.WK,3,true,true,TermType.M,PaymentType.CC,ValidationData_Genesis.SuccessValidationMessage},
                    {"",CustomerType.STD, PaymentFrequency.MN,4,false,false,TermType.M,PaymentType.BA,ValidationData_Genesis.SuccessValidationMessage},
                    {"",CustomerType.TF, PaymentFrequency.WK,2.5,true,false,TermType.P,PaymentType.CC,ValidationData_Genesis.SuccessValidationMessage},
                    {"",CustomerType.RE, PaymentFrequency.MN,3.5,true,true,TermType.P,PaymentType.CC,ValidationData_Genesis.SuccessValidationMessage},
                    {"Cus Id 112",CustomerType.STD,PaymentFrequency.MN,4,true,false,TermType.P,PaymentType.CC,ValidationData_Genesis.SuccessValidationMessage},

                })
                .BDDfy();
        }



        public virtual void WhenPaymentTypeSelected(string customerid, CustomerType customertype, PaymentFrequency payFrequency, int installmentamount, bool firstOneOffPayment, bool secondOneOffPayment, TermType termType, PaymentType paymentType, GenesisTemplateDetailsModel model)
        {
            model.ContractModel.BusinessId = customerid;
            model.ContractModel.CustomerType = customertype;
            model.PaymentPlanModel.PaymentFrequency = payFrequency;
            model.PaymentPlanModel.InstalmentAmount = installmentamount;
            model.PaymentPlanModel.FirstOneOff = firstOneOffPayment;
            model.PaymentPlanModel.SecondOneOff = secondOneOffPayment;
            model.PaymentPlanModel.TermType = termType;
            model.PaymentModel.PaymentType = paymentType;

            ConfirmationPage = TemplateDetailsPage.ContractTab
            .UpdateContractTab(model.ContractModel).Next<CustomerDetailsTab_Genesis>()
            .UpdateCustomerDetailsTab(model.CustomerDetailsModel).Next<PaymentPlanTab_Genesis>()
            .UpdatePaymentPlanTab(model.PaymentPlanModel)
            .Initial().Next<BasePaymentTab>()
            .UpdatePaymentTab(model.PaymentModel).Next<ParqTab_Genesis>()
            .UpdateParqTab(model.ParqModel).Next<BaseSignaturesTab>()
            .SignAll()
            .Submit();
            
            ConfirmationPage.ViewCustomerDetails();
            ConfirmationPage.ReadDebitSuccessId();
         }

        
    }
}
