﻿using System.Threading;
using OpenQA.Selenium;
using TestStack.Seleno.PageObjects;
using WebDirectEntry.AutomatedTests.Genesis.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.Genesis.Pages
{
    public class ParqTab_Genesis : DirectEntryBasePage
    {
        private string _pageTitle = "Parq";

        public virtual string PageTitle
        {
            get { return _pageTitle; }
            set { _pageTitle = value; }
        }

        public virtual ParqTab_Genesis UpdateParqTab(GenesisParqModel model)
        {
            Thread.Sleep(2000);
            HeartConditionSurvey = model.HeartConditionSurvey;
            ChestPainSurvey = model.ChestPainSurvey;
            FaintSurvey = model.FaintSurvey;
            AsthmaSurvey = model.AsthmaSurvey;
            DiabeteSurvey = model.DiabeteSurvey;
            MuscleSurvey = model.MuscleSurvey;
            OtherSurvey = model.OtherSurvey;
            return this;
        }

        public virtual bool HeartConditionSurvey
        {
            set
            {
                if (value)
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_0__Value][value=Y]")).Click();
                }
                else
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_0__Value][value=N]")).Click();
                    
                }
            }
        }

        public virtual bool ChestPainSurvey
        {
            set
            {
                if (value)
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_1__Value][value=Y]")).Click();
                }
                else
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_1__Value][value=N]")).Click();
                }
            }
        }

        public virtual bool FaintSurvey
        {
            set
            {
                if (value)
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_2__Value][value=Y]")).Click();
                }else
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_2__Value][value=N]")).Click();
                }
            }
        }

        public virtual bool AsthmaSurvey
        {
            set
            {
                if (value)
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_3__Value][value=Y]")).Click();
                }
                else
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_3__Value][value=N]")).Click();
                }
            }
        }

        public virtual bool DiabeteSurvey
        {
            set
            {
                if (value)
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_4__Value][value=Y]")).Click();
                }else
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_4__Value][value=N]")).Click();
                }
            }
        }

        public virtual bool MuscleSurvey
        {
            set
            {
                if (value)
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_5__Value][value=Y]")).Click();
                }else
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_5__Value][value=N]")).Click();
                }
            }
        }

        public virtual bool OtherSurvey
        {
            set
            {
                if (value)
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_6__Value][value=Y]")).Click();
                }
                else
                {
                    Find.Element(By.CssSelector("input[id=Sections_5__Elements_6__Value][value=N]")).Click();
                }
            }
        }

        public virtual T Next<T>() where T : Page, new()
        {
            return Navigate.To<T>(By.Id("btnSectionNextButtonPARQEnabledBottom"));
        }

    }
}
