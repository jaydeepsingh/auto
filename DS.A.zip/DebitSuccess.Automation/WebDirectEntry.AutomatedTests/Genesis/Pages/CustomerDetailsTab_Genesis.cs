﻿using DebitSuccess.Automation.Framework.Extensions;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Genesis.Models;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.Genesis.Pages
{
    public class  CustomerDetailsTab_Genesis : BaseCustomerDetailsTab
    {
        public override BaseCustomerDetailsTab UpdateCustomerDetailsTab(BaseCustomerDetailsModel model)
        {
            var genesisModel = (GenesisCustomerDetailsModel) model; 

            Find.SendDirectEntryDataToForm(new
            {
                model.Gender,
                model.FirstName,
                model.LastName,
                model.DateOfBirth,
                model.MailingAddress,
                model.Suburb,
                model.Postcode,
                State = State.NSW,
                model.EmailAddress,
                model.PhoneHome,
                model.PhoneWork,
                model.PhoneMobile,
                model.PhoneEmergency,
                model.EmergencyContactName,
                genesisModel.SourceOfIntroduction
            });
            Find.TakeTestScreenshot("CustomerDetails Tab");
            
            return this;
        }
    }
}
