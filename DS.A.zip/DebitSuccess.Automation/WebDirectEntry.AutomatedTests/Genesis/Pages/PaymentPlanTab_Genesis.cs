﻿using DebitSuccess.Automation.Framework.Extensions;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Genesis.Models;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.Genesis.Pages
{
    public class PaymentPlanTab_Genesis : BasePaymentPlanTab
    {
        
        public override BasePaymentPlanTab UpdatePaymentPlanTab(BasePaymentPlanModel model)
        {
            var genesisModel = (GenesisPaymentPlanModel) model;

            if (model.InstalmentAmount > 0)
            {
                InstalmentAmount = model.InstalmentAmount.ToString();
            }
            else
            {
                InstalmentAmount = "";
            }

            Find.SendDirectEntryDataToForm(new
            {
                genesisModel.PaymentFrequency,
                genesisModel.JoiningFeePaymentType,
                model.TermType,
                genesisModel.CancellationFee,
                genesisModel.JoiningFee
            });

            if ((model.TermType).ToString() == "P")
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.MinimumTermPayments
                });
            }
            else
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.MinimumTermMonths
                });
            }

            if (model.InstalmentAmount > 0) //can't fill some fields if instalment amount is not filled
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.FirstPaymentDate,
                    model.BillingFee
                });
            }
           if (model.FirstOneOff)
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.FirstOneOff,
                    model.AddOneOffPaymentOne.FirstOneOffAmount,
                    model.AddOneOffPaymentOne.FirstOneOffDesc,
                    model.AddOneOffPaymentOne.FirstOneOffDate
                });
            }
            if (model.SecondOneOff)
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.SecondOneOff,
                    model.AddOneOffPaymentTwo.SecondOneOffAmount,
                    model.AddOneOffPaymentTwo.SecondOneOffDesc,
                    model.AddOneOffPaymentTwo.SecondOneOffDate
                });
            }

            Find.TakeTestScreenshot("Payment Plan Tab");
            return this;
        }


        public BasePaymentPlanTab UpdatePaymentPlanTabPaidInFull(BasePaymentPlanModel model)
        {
            var genesisModel = (GenesisPaymentInFullPlanModel) model;

            Find.SendDirectEntryDataToForm(new
            {
                PaidInFull = genesisModel.PaidInFull,
                genesisModel.PaidInFullJoiningFee,
                genesisModel.PaidInFullMembershipFee,
                genesisModel.PaidInFullPayMethod,
                genesisModel.CancellationFee,
                genesisModel.SuspensionFee,
                genesisModel.SpecialConditions,
                genesisModel.AcceptTsAndCsForPaidInFull



            });
            Find.TakeTestScreenshot("Payment Plan Tab");
            //TODO
            return this;
        }
    }
}
