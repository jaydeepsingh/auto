﻿using System.Collections.Generic;

namespace WebDirectEntry.AutomatedTests.Genesis.Data
{
    public class ValidationData_Genesis
    {
        public static List<string> CustomerDetailsTabEmptyFieldsMessages
        {
            get
            {
                return new List<string>
                {
                    "First name or last name is required",
                    "Date of birth is required",
                    "Mailing address is required",
                    "Suburb is required",
                    "Postcode is required",
                    "Email is required",
                    "At least one phone number is required",
                    "Enter a valid phone number",
                    "Emergency contact name is required",
                    "Source Of Introduction is required"
                };
            }
        }

        public static string SuccessValidationMessage = "The contract has been submitted successfully.";
    }
}
