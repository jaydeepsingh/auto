﻿using System;
using WebDirectEntry.AutomatedTests.Genesis.Models;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.Genesis.Data
{
    public class GenesisTemplateData
    {
        private const string DateOfBirth = "19/07/1987";
        private static readonly string FirstPaymentDate = DateTime.Now.AddDays(1).ToString("dd/MM/yyyy");
        private static readonly DateTime TodaysDate = DateTime.Today.Date;
        private static readonly string OneOffFirstPaymentDate = TodaysDate.AddDays(2).ToString("dd/MM/yyyy");
        public static GenesisTemplateDetailsModel BaseGenesisData = new GenesisTemplateDetailsModel
        {
            ContractModel = new GenesisContractModel
            {
                DebitsuccessIdentifier = DebitsuccessIdentifierDropdown.DST1,
                CustomerType = CustomerType.STD
            },

            CustomerDetailsModel = new GenesisCustomerDetailsModel
            {
                Gender = GenderType.M,
                FirstName = "Testcase",
                LastName = "Wde",
                DateOfBirth = DateOfBirth,
                MailingAddress = "19 Queen Street",
                Suburb = "CBD",
                Postcode = "1010",
                State = State.NSW,
                City = "Auckland",
                EmailAddress = "Facility1@debitsuccess.com",
                PhoneHome = "091234567",
                PhoneWork = "098912345",
                PhoneMobile = "021021021",
                PhoneEmergency = "027027027",
                EmergencyContactName = "Mr Emergency",
                SourceOfIntroduction = "Mr SourceOfIntroduction"
            },

            PaymentPlanModel = new GenesisPaymentPlanModel
            {
                PaidInFull = false,
                PaymentFrequency = PaymentFrequency.WK,
                InstalmentAmount = 2.5,
                BillingFee = 49,
                JoiningFee = 50,
                FirstPaymentDate = FirstPaymentDate,
                JoiningFeePaymentType = JoiningFeePaymentType.FirstInstalment,
                TermType = TermType.M,
                MinimumTermMonths = 12,
                MinimumTermPayments = 100,
                FirstOneOff = true,
                SecondOneOff = false,
                AddOneOffPaymentOne =
                    new BaseAddOneOffPaymentModelOne()
                    {
                        FirstOneOffAmount = 100,
                        FirstOneOffDesc = "First one-off payment added",
                        FirstOneOffDate = OneOffFirstPaymentDate
                    },
                AddOneOffPaymentTwo =
                    new BaseAddOneOffPaymentModelTwo()
                    {
                        SecondOneOffAmount = 100,
                        SecondOneOffDesc = "Second one-off payment added",
                        SecondOneOffDate = OneOffFirstPaymentDate
                    },
                TerminateAfterMinTerm = false,
                Initials = true,
                CancellationFee = 149,
                SuspensionFee = 50,
                SpecialConditions = "Special Condition!!!"

            },

            PaymentInfullPlanModel = new GenesisPaymentInFullPlanModel
            {
                PaidInFull = true,
                PaidInFullJoiningFee = 50,
                PaidInFullMembershipFee = 100,
                PaidInFullPayMethod = PaymentMethod.CQ,
                CancellationFee = 149,
                SuspensionFee = 50,
                //SpecialConditions = "Special Condition Chippy!!!",
                AcceptTsAndCsForPaidInFull = true
            },

            PaymentModel = new GenesisPaymentModel
            {
                PaymentType = PaymentType.CC,
                CreditCard = new CreditCardModel { Name = "AT Test", CreditCardType = CreditCardType.VI, ExpiryMonth = "12", ExpiryYear = "19", FirstDigits = "4111", SecondDigits = "1111", ThirdDigits = "1111", FourthDigits = "1111" },
                BankAccountDetails = new BankAccountModel { BankAccountName = "TestAccount", BankAccountNumber = "12342800", BankIdentifier = "123456", BankName = "ASB" },
                PreviewTermsAndConditionsButton = true,
                AcceptTermsAndConditionsCheckBox = true
            },

            ParqModel = new GenesisParqModel
            {
                HeartConditionSurvey = true,
                ChestPainSurvey = true,
                FaintSurvey = true,
                AsthmaSurvey = true,
                DiabeteSurvey = true,
                MuscleSurvey = true,
                OtherSurvey = true
            },

            SignaturesModel = new GenesisSignaturesModel
            {
                SignCustomerButton = true,
                SignJointAccountHolderButton = true,
                SignWitnessButton = true
            }
        };
    }
}
