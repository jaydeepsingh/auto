﻿using DebitSuccess.Automation.Framework.Controls;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.Genesis.Models
{
    public class GenesisTemplateDetailsModel
    {
        public GenesisContractModel ContractModel { get; set; }
        public GenesisCustomerDetailsModel CustomerDetailsModel { get; set; }
        public GenesisPaymentPlanModel PaymentPlanModel { get; set; }
        public GenesisPaymentInFullPlanModel PaymentInfullPlanModel { get; set; }
        public GenesisPaymentModel PaymentModel { get; set; }
        
        public GenesisParqModel ParqModel { get; set; }
        public GenesisSignaturesModel SignaturesModel { get; set; }
    }

    public class GenesisContractModel : BaseContractModel
    {
       
    }

    public class GenesisCustomerDetailsModel : BaseCustomerDetailsModel
    {
        public string SourceOfIntroduction { get; set; }
    }

    public class GenesisPaymentPlanModel : BasePaymentPlanModel
    {
        public bool PaidInFull { get; set; }
        public int JoiningFee { get; set; }
        public JoiningFeePaymentType JoiningFeePaymentType { get; set; }
    }


    public class GenesisPaymentInFullPlanModel : BasePaymentPlanModel
    {
        public bool PaidInFull { get; set; }
        public int PaidInFullJoiningFee { get; set; }

        public int PaidInFullMembershipFee { get; set; }

        public PaymentMethod PaidInFullPayMethod { get; set; }

        public bool AcceptTsAndCsForPaidInFull { get; set; }
    }

    public class GenesisPaymentModel : BasePaymentModel
    {
    }

    public class GenesisParqModel
    {
        public bool HeartConditionSurvey { get; set; }
        public bool ChestPainSurvey { get; set; }
        public bool FaintSurvey { get; set; }
        public bool AsthmaSurvey { get; set; }
        public bool DiabeteSurvey { get; set; }
        public bool MuscleSurvey { get; set; }
        public bool OtherSurvey { get; set; }
    }

    public class GenesisSignaturesModel : BaseSignaturesModel
    {
    }

    [RadioButton]
    public enum JoiningFeePaymentType
    {
        FirstInstalment,
        PaidAtFacility
    }

    [RadioButton]
    public enum PaymentMethod
    {
        CQ,
        CH,
        EF,
        VI,
        MA
    }


}
