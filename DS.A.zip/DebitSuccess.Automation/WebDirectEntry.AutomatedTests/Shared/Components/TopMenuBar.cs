﻿using System.Collections.Generic;
using OpenQA.Selenium;
using TestStack.Seleno.PageObjects;
using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.Shared.Components
{
    public class TopMenuBar : UiComponent
    {


            public BaseTemplatesListPage TemplatesTab()
            {
                return Navigate.To<BaseTemplatesListPage>(By.LinkText("Templates"));
            }

            public void AdministrationTab()
            {
                Find.Element(By.ClassName("dropdown open")).Click();
            }

            public void Permissions()
            {

            }

            public void BusinessSettings()
            {

            }

            public void UserMenu()
            {
                List<IWebElement> elements = Find.Elements(By.ClassName("dropdown")) as List<IWebElement>;
                if (elements != null) elements[1].Click();
            }
        
    }
}
