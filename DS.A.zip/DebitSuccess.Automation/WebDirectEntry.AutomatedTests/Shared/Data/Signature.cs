﻿using System;
using System.Collections.Generic;

namespace WebDirectEntry.AutomatedTests.Shared.Data
{
    public static class Signature
    {
        public static List<Coordinates> Coordinates()
        {
            var drawingCoordinates = new List<Coordinates>
                {
                    new Coordinates{X= 200, Y = 200},
                    new Coordinates{X = 200, Y = 400},
                };

            return drawingCoordinates;
        }
    }

    public class Coordinates
    {
        public int X { get; set; }
        public int Y { get; set; }
    }

}
