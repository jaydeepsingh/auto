﻿using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.Shared.Data
{
    public class LoginData
    {
        public static LoginModel OmgdemoMasterUser = new LoginModel()
        {
            CompanyId = "omgdemo",
            UserName = "master",
            Password = "Passw0rd"
        };

        public static LoginModel AtMasterUser = new LoginModel()
        {
            CompanyId = "atuser",
            UserName = "master",
            Password = "Passw0rd"
        };

        public static LoginModel AtSubUser = new LoginModel()
        {
            CompanyId = "atuser",
            UserName = "yalu.y@debitsuccess.com",
            Password = "Passw0rd"
        };

        public static LoginModel UserWithWrongPass = new LoginModel()
        {
            CompanyId = "omgdemo",
            UserName = "master",
            Password = "xyz"
        };

        public static LoginModel DstUser = new LoginModel()
        {
            CompanyId = "dst",
            UserName = "master",
            Password = "Passw0rd"
        };
        
        public static string LoginPermissionError = "The supplied credentials are either insufficient or incorrect. Please try again.";

        
    }

}