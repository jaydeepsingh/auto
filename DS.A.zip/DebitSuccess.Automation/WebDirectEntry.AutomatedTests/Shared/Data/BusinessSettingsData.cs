﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.Shared.Data
{
    public class BusinessSettingsData
    {
        
        public static BusinessSettingsModel DefualtSettings = new BusinessSettingsModel()
        {
            PaymentMethod = new PaymentMethods()
            {
                BankAccount = true,
                CreditCard = true
            },
            PaymentFrequency = new PaymentFrequencies()
            {
                Weekly = true,
                Fortnightly = true,
                FourWeekly = true,
                Monthly = true,
                Quarterly = true
            },
            IncludeBillingFee = true,
            DaysUntilFirstPaymentDate = 2,
            MinimumWeeklyRate = "",
            MaximumWeeklyRate = "",
            CancellationFee = "",
            SuspensionFee = "",
            BillingFee = ""
           
        };
    }
}
