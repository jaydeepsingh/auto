﻿using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.Shared.Data
{
    public class LegalBusinessData
    {
        public static LegalBusinessDataModel DST1 = new LegalBusinessDataModel
        {
            DebitsuccessIdentifier = "DST1",
            BusinessName = "Debitsuccess Test",
            LegalName = "Genesis Ringwood",
            LegalAddress = "1 Ringwood Street, Ringwood",
            AbnAcn = "123",
            BusinessAccountDescription = "DebitSuccess Test 987654321 WWW.DEBITSUCCESS.COM",
            DebitsuccessId = "DST1"
        };

        public static LegalBusinessDataModel ATFA1 = new LegalBusinessDataModel
        {
            DebitsuccessIdentifier = "ATFA1",
            BusinessName = "Automated Testing Facility",
            LegalName = "AT Facility Ltd.",
            LegalAddress = "5 Queen Street, Auckland CBD",
            AbnAcn = "AT ABN",
            BusinessAccountDescription = "AT Facility Account 01",
            DebitsuccessId = "ATFA1"
        };
    }
}
