﻿
namespace WebDirectEntry.AutomatedTests.Shared.Data
{
    public class TemplateNames
    {
        public static readonly string StandardAusQldAndWa = "Debitsuccess Standard AUS - QLD and WA";
        public static readonly string StandardAus = "Debitsuccess Standard AUS";
        public static readonly string StandardNz = "Debitsuccess Standard NZ";
        public static readonly string DebitsuccessStandardNZOffline = "Debitsuccess Standard NZ - Offline";
        public static readonly string StandardAusSa = "Debitsuccess Standard AUS - SA";
        public static readonly string StandardUs = "Debitsuccess Standard US";
        public static readonly string Genesis = "Genesis";
        public static readonly string GenesisWa = "Genesis WA";
       

    }
}
