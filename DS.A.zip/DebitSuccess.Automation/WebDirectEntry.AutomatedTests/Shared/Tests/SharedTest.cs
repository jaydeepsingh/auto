﻿using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using DebitSuccess.AutomatedTests.Common.Base;
using DebitSuccess.Automation.Framework.Extensions;
using DebitSuccess.Automation.Framework.Fixtures;
using FluentAssertions;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.Shared.Components;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.Shared.Tests
{
    public class SharedTest : BaseTest
    {
        public string TemplateName { get; protected set; }

        public LoginPage LoginPage { get; protected set; }
        public BaseContractTab ContractTab { get; protected set; }
        public BaseCustomerDetailsTab CustomerDetailsTab { get; protected set; }
        public BasePaymentPlanTab PaymentPlanTab { get; protected set; }
        public BasePaymentTab PaymentTab { get; protected set; }
        public BaseSignaturesTab SignaturesTab { get; protected set; }
        public TemplateDetailsPage TemplateDetailsPage { get; protected set; }
        public BaseTemplatesListPage TemplateListPage { get; protected set; }
        public ConfirmationPage ConfirmationPage { get; protected set; }


        public SharedTest(TestClassFixture testClassFixture)
            : base(testClassFixture)
        {
        }

        public virtual void GivenISelectDirectEntryTemplate(string templateName, LoginModel user)
        {

           
            TemplateDetailsPage = GoToDirectEntryTemplate(templateName, user);
           
        }

        public virtual void GivenDefaultBusinessSettingsOnWde(LoginModel user,string BusinessAccountname,string templateName)
        {
            if (TestClassFixture.Properties.IsLoggedIn != null && TestClassFixture.Properties.IsLoggedIn)
            {
                TemplateListPage = GoTo<BaseTemplatesListPage>();
            }
            else
            {

                TemplateListPage = GoTo<LoginPage>().LoginWithUser(user);
                TestClassFixture.Properties.IsLoggedIn = true;
                GoTo<BusinessSettingsPage>().ChangeBusinessSettings(BusinessAccountname);
            }
            TemplateDetailsPage = TemplateListPage.ClickTemplate(templateName);
        }

        public virtual void ThenIShouldBeAbleToSeeSuccessfulMessage()
        {
            ConfirmationPage.RegistrationSuccessful().Should().BeTrue();
        }

        public virtual void ThenIShouldSeeValidateErrorMessagesOnPage(List<string> expectedErrorMessages, List<string> errorMessagesOnPage)
        {
            (errorMessagesOnPage.Count > 0 && expectedErrorMessages.All(errorMessagesOnPage.Contains)).Should().BeTrue();
        }

        public virtual void ThenIShouldSeeTheValidateErrorMessageOnPage(string expectedErrorMessage, List<string> errorMessagesOnPage)
        {
            errorMessagesOnPage.Contains(expectedErrorMessage).Should().BeTrue();
        }

        public TemplateDetailsPage GoToDirectEntryTemplate(string templateName, LoginModel user)
        {

            if (TestClassFixture.Properties.IsLoggedIn != null && TestClassFixture.Properties.IsLoggedIn)
            {
                TemplateListPage = GoTo<BaseTemplatesListPage>();
            }
            else
            {
                
                TemplateListPage = GoTo<LoginPage>().LoginWithUser(user);
                TestClassFixture.Properties.IsLoggedIn = true;
            }

            TemplateDetailsPage = TemplateListPage.ClickTemplate(templateName);
            return TemplateDetailsPage;
        }

        




        public bool VerifyValidationErrorMessages(List<string> validationErrorMessagesDisplayed,List<string> validationErrorMessages)
        {
            for (var i = 0; i < validationErrorMessages.Count; i++)
            {
                if (!validationErrorMessagesDisplayed[i].Equals(validationErrorMessages[i]))
                {
                    return false;
                }
            }
            return true;
        }

        public virtual void ThenIShouldSeeValidateSuccessMessagesOnPage(string expectedMessage, string actualmessage)
        {

            (actualmessage.Contains(expectedMessage)).Should().BeTrue();




        }
    }
}