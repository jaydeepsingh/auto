﻿namespace WebDirectEntry.AutomatedTests.Shared.Models
{
    public class LegalBusinessDataModel
    {
        public string DebitsuccessIdentifier { get; set; }
        public string BusinessName { get; set; }
        public string LegalName { get; set; }
        public string LegalAddress { get; set; }
        public string AbnAcn { get; set; }
        public string BusinessAccountDescription { get; set; }
        public string DebitsuccessId{ get; set; }
    }
}
