﻿using DebitSuccess.Automation.Framework.Controls;
using WebDirectEntry.AutomatedTests.Genesis.Models;

namespace WebDirectEntry.AutomatedTests.Shared.Models
{
    public class BaseTemplateDetailsModel
    {
        public BaseContractModel ContractModel { get; set; }
        public BaseCustomerDetailsModel CustomerDetailsModel { get; set; }
        public BasePaymentPlanModel PaymentPlanModel { get; set; }
        public BasePaymentModel PaymentModel { get; set; }
        public BaseSignaturesModel SignaturesModel { get; set; }
    }

    public class BaseContractModel
    {
        public DebitsuccessIdentifierDropdown DebitsuccessIdentifier { get; set; }
        public string BusinessId { get; set; }
        public CustomerType CustomerType { get; set; }
    }

    public class BaseCustomerDetailsModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public GenderType Gender { get; set; }
        public string DateOfBirth { get; set; }
        public string MailingAddress { get; set; }
        public string Suburb { get; set; }
        public string City { get; set; }
        public string Postcode { get; set; }
        public State State { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneHome { get; set; }
        public string PhoneWork { get; set; }
        public string PhoneMobile { get; set; }
        public string PhoneEmergency { get; set; }
        public string EmergencyContactName { get; set; }

    }

    public class BasePaymentPlanModel
    {
        public PaymentFrequency PaymentFrequency { get; set; }
        public double InstalmentAmount { get; set; }
        public int BillingFee { get; set; }
        public string FirstPaymentDate { get; set; }
        public TermType TermType { get; set; }
        public int MinimumTermMonths { get; set; }
        public int MinimumTermPayments { get; set; }
        public bool FirstOneOff { get; set; }
        public bool SecondOneOff { get; set; }
        public BaseAddOneOffPaymentModelOne AddOneOffPaymentOne { get; set; }
        public BaseAddOneOffPaymentModelTwo AddOneOffPaymentTwo { get; set; }
        public bool TerminateAfterMinTerm { get; set; }
        public bool Initials { get; set; }
        public int CancellationFee { get; set; }
        public int SuspensionFee { get; set; }
        public SpecialConditionsDropdownMenu SpecialConditionsDropDown { get; set; }
        public string SpecialConditions { get; set; }
    }


    public class BasePaymentModel
    {
        public PaymentType PaymentType { get; set; }
        public CreditCardModel CreditCard { get; set; }
        public BankAccountModel BankAccountDetails { get; set; }
        public bool PreviewTermsAndConditionsButton { get; set; }
        public bool AcceptTermsAndConditionsCheckBox { get; set; }
    }

    public class BaseSignaturesModel
    {
        public bool SignCustomerButton { get; set; }
        public bool SignJointAccountHolderButton { get; set; }
        public bool SignWitnessButton { get; set; }
    }

    [Dropdown]
    public enum DebitsuccessIdentifierDropdown
    {
        DST1,
        DST2,
        DST3,
        DST4,
        DST5,
        ATFA1

    }

    [RadioButton]
    public enum CustomerType
    {
        STD,
        RE,
        TF
    }

    public class OmgCustomerDetailsModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

    [RadioButton]
    public enum GenderType
    {
        M,
        F
    }

    [RadioButton]
    public enum TermType
    {
        M,
        P
    }

    [RadioButton]
    public enum PaymentType
    {
        CC,
        BA
    }

    [RadioButton]
    public enum PaymentFrequency
    {
        WK,
        FN,
        FW,
        MN,
        QT
    }

    [Dropdown]
    public enum State
    {
        ACT, 
        NSW, 
        NT, 
        QLD, 
        TAS, 
        VIC, 
        WA
    }

    [Dropdown]
    public enum SpecialConditionsDropdownMenu
    {
        //TODO:
    }
    public class BaseAddOneOffPaymentModelOne : BasePaymentPlanModel
    {
        public int FirstOneOffAmount { get; set; }
        public string FirstOneOffDesc { get; set; }
        public string FirstOneOffDate { get; set; }
    }

    public class BaseAddOneOffPaymentModelTwo : BasePaymentPlanModel
    {
        public int SecondOneOffAmount { get; set; }
        public string SecondOneOffDesc { get; set; }
        public string SecondOneOffDate { get; set; }
    }

}