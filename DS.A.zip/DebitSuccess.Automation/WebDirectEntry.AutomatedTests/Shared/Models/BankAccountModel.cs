﻿namespace WebDirectEntry.AutomatedTests.Shared.Models
{
    public class BankAccountModel
    {
        public virtual string BankAccountName { get; set; }
        public virtual string BankAccountNumber { get; set; }
        public virtual string BankIdentifier { get; set; }
        public virtual string BankName { get; set; }
    }
}