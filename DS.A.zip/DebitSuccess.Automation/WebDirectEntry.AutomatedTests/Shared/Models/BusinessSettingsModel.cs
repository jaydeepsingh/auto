﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using WebDirectEntry.AutomatedTests.Genesis.Models;

namespace WebDirectEntry.AutomatedTests.Shared.Models
{
    public class BusinessSettingsModel
    {
        public PaymentMethods PaymentMethod { get; set; }
        public PaymentFrequencies PaymentFrequency { get; set; }
        public bool IncludeBillingFee { get; set; }
        public int DaysUntilFirstPaymentDate { get; set; }

        public string MinimumWeeklyRate { get; set; }
        public string MaximumWeeklyRate { get; set; }
        public string CancellationFee { get; set; }
        public string SuspensionFee { get; set; }

        public string BillingFee { get; set; }





    }

    public class PaymentMethods
    {
        public bool CreditCard { get; set; }
        public bool BankAccount { get; set; }
    }


    public class PaymentFrequencies
    {
        public bool Weekly { get; set; }
        public bool Fortnightly { get; set; }

        public bool FourWeekly { get; set; }
        public bool Monthly { get; set; }

        public bool Quarterly { get; set; }
        
    
    }
}