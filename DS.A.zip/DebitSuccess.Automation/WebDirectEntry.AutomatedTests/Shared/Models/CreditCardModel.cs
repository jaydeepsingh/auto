﻿namespace WebDirectEntry.AutomatedTests.Shared.Models
{
    public class CreditCardModel
    {
        public virtual string Name { get; set; }
        public virtual string FirstDigits { get; set; }
        public virtual string SecondDigits { get; set; }
        public virtual string ThirdDigits { get; set; }
        public virtual string FourthDigits { get; set; }
        public virtual string ExpiryMonth { get; set; }
        public virtual string ExpiryYear { get; set; }
        public virtual CreditCardType CreditCardType { get; set; }
    }
    
    public enum CreditCardType
    {
        VI,
        MA,
        AM
    }
}