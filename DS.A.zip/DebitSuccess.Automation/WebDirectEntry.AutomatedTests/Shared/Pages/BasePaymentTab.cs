﻿using System.Threading;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using TestStack.Seleno.PageObjects;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class BasePaymentTab : DirectEntryBasePage
    {

        public virtual CreditCardModel CreditCard
        {

            get { return Find.ModelFromPage<CreditCardModel>(); }

            set
            {
                Find.Element(By.CssSelector("input[name$=CreditCardName]")).ClearAndSendKey(value.Name);
                Find.Element(By.CssSelector("input[name$=CreditCardNumberFirst]")).ClearAndSendKey(value.FirstDigits);
                Find.Element(By.CssSelector("input[name$=CreditCardNumberSecond]")).ClearAndSendKey(value.SecondDigits);
                Find.Element(By.CssSelector("input[name$=CreditCardNumberThird]")).ClearAndSendKey(value.ThirdDigits);
                Find.Element(By.CssSelector("input[name$=CreditCardNumberFourth]")).ClearAndSendKey(value.FourthDigits);
                Find.Element(By.CssSelector("select[name$=CreditCardExpiryMonth]")).SendKeys(value.ExpiryMonth);
                Find.Element(By.CssSelector("select[name$=CreditCardExpiryYear]")).SendKeys(value.ExpiryYear);

                Execute.Script("$('input[type=radio][value="+value.CreditCardType+"]:visible').trigger('click')");
            }
        }



        public virtual BasePaymentTab UpdatePaymentTab(BasePaymentModel model)
        {
            Find.SendDirectEntryDataToForm(new { model.PaymentType});

            if (model.PaymentType == PaymentType.CC)
            {
                CreditCard = model.CreditCard; 

            }
            else
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.BankAccountDetails.BankName,
                    model.BankAccountDetails.BankAccountName,
                    model.BankAccountDetails.BankIdentifier,
                    model.BankAccountDetails.BankAccountNumber
                });
            }

            EnableTAndCCheckBox();
            
            Thread.Sleep(1000); //needs some time for 'Accept Terms And Conditions' checkbox to be activated
            
            Find.SendDirectEntryDataToForm(new {AcceptTsAndCs = true});

            Find.TakeTestScreenshot( "Payment Tab");

            return this;
        }

        public virtual void EnableTAndCCheckBox()
        {
            Execute.Script("$('input[Key=AcceptTsAndCs]').removeAttr('disabled')");
        }

        public virtual T Next<T>() where T : Page, new()
        {
            return Navigate.To<T>(By.Id("btnSectionNextButtonPaymentEnabledBottom"));
        }
    }
}