﻿using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class LoginPage : DirectEntryBasePage
    {
        public BaseTemplatesListPage LoginWithUser(LoginModel user)
        {
            Find.SendModelToPage(user);
            
            Find.TakeTestScreenshot("LoginPage");
            
            return Navigate.To<BaseTemplatesListPage>(By.CssSelector(".btn[type=submit]")); 
        }
    }
}

