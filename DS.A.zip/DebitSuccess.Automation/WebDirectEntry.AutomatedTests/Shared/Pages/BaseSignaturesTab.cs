﻿using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using WebDirectEntry.AutomatedTests.Extensions;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class BaseSignaturesTab : DirectEntryBasePage
    {
        public virtual void SignCustomer()
        {
            Execute.Script("$('div[key=SignatureCustomer] .btn-warning').trigger('click')");
            Find.GetDriver().Sign();
        }

        public virtual void SignJoint()
        {
            Execute.Script("$('div[key=SignatureJoint] .btn-warning').trigger('click')");
            Find.GetDriver().Sign();
        }

        public virtual void SignWitness()
        {
            Execute.Script("$('div[key=SignatureWitness] .btn-warning').trigger('click')");
            Find.GetDriver().Sign();
        }

        public virtual BaseSignaturesTab SignAll()
        {
            SignCustomer();
            SignJoint();
            SignWitness();

            return this;
        }

        public ConfirmationPage Submit()
        {
            
            return Navigate.To<ConfirmationPage>(By.Name("page-submit-btn"));
            
        }
    }
}