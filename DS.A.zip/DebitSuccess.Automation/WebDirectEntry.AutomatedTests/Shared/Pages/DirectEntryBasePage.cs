﻿using System;
using System.Linq;
using DebitSuccess.AutomatedTests.Common.CommonComponents;
using TestStack.Seleno.PageObjects;
using WebDirectEntry.AutomatedTests.Shared.Components;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class DirectEntryBasePage : Page
    {
        /// <summary>
        /// Gets the error message component.
        /// </summary>
        /// <value>
        /// The error message component.
        /// </value>
        public ErrorSummary ErrorMessageComponent { get { return GetComponent<ErrorSummary>(); } }

        /// <summary>
        /// Menu bar at the top of the page
        /// </summary>
        public TopMenuBar BaseTopMenuBar { get { return GetComponent<TopMenuBar>(); } }

        /// <summary>
        /// There's validation error on the page and it cannot proceed further
        /// </summary>
        public void CheckErrorPresentsOnPage()
        {
            var component = GetComponent<ErrorSummary>();
            var errors = component.ValidationErrorMessages;
            if (errors.Count > 0)
            {
                throw new Exception("Validation Errors Presents:" + errors.Aggregate((i, j) => i + "," + j));
            }
        }


    }
}