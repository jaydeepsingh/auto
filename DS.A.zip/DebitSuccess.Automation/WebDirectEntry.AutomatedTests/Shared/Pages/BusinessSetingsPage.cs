﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using TestStack.Seleno.PageObjects.Actions;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Genesis.Models;
using WebDirectEntry.AutomatedTests.Shared.Data;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;
using By = TestStack.Seleno.PageObjects.Locators.By;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class BusinessSettingsPage : DirectEntryBasePage
    {
        public BaseTemplatesListPage ChangeBusinessSettings(string businessAccountname)
        {
            IWebElement menuElement = Find.Element(By.LinkText("Administration"));
            if (menuElement != null) menuElement.Click();
            Find.Element(By.LinkText("Business Settings")).Click();
            SelectBusinessAccount(businessAccountname);
            UpdateBusinessSettings(BusinessSettingsData.DefualtSettings);
            return Navigate.To<BaseTemplatesListPage>(By.LinkText("Templates"));


            /*
            Find.Element(By.CssSelector("a[id='tabForm_Optional']")).Click();
            */

        }

        public void SelectBusinessAccount(string businessAccountname)
        {

            Find.Element(By.PartialLinkText(businessAccountname)).Click();

        }

        public virtual BusinessSettingsPage UpdateBusinessSettings(BusinessSettingsModel model)
        {
            Thread.Sleep(2000);
            Find.SendBusinessSettingsDataToForm(new
            {
                model.PaymentMethod.CreditCard,
                model.PaymentMethod.BankAccount
            });
            Find.Element(By.LinkText("Optional")).Click();
            Find.SendBusinessSettingsDataToForm(new
            {
                
                model.DaysUntilFirstPaymentDate,
                model.PaymentFrequency.Weekly,
                model.PaymentFrequency.Fortnightly,
                model.PaymentFrequency.FourWeekly,
                model.PaymentFrequency.Monthly,
                model.PaymentFrequency.Quarterly,
                model.MinimumWeeklyRate,
                model.MaximumWeeklyRate,
                model.CancellationFee,
                model.SuspensionFee,
                model.BillingFee

            });

            IncludeBillingFee = model.IncludeBillingFee;

            return Navigate.To<BusinessSettingsPage>(By.CssSelector(".btn[type=submit]"));
        }
        

      
        public virtual bool IncludeBillingFee
        {
            set
            {
                if (value)
                {
                    if (!(Find.Element(By.CssSelector("input[id='FacilityAccountSettings_Tags_23__Value']")).Selected))
                    {
                        Find.Element(By.CssSelector("input[id='FacilityAccountSettings_Tags_23__Value']")).Click();
                    }
                }
                else
                {
                    if (Find.Element(By.CssSelector("input[id='FacilityAccountSettings_Tags_23__Value']")).Selected)
                    {
                        Find.Element(By.CssSelector("input[id='FacilityAccountSettings_Tags_23__Value']")).Click();
                    }
                }
            }
        }
    }
}





