﻿using OpenQA.Selenium;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Pages;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class TemplateDetailsPage : DirectEntryBasePage
    {
        public virtual BaseTemplatesListPage TemplatesTab
        {
            get
            {
                return Navigate.To<BaseTemplatesListPage>(By.LinkText("Templates"));
            }
        }

        public virtual BaseContractTab ContractTab
        {
            get
            {
                return Navigate.To<BaseContractTab>(By.LinkText("Contract"));
            }
        }

        public virtual BaseCustomerDetailsTab CustomerDetailsTab
        {
            get
            {
                return Navigate.To<BaseCustomerDetailsTab>(By.LinkText("Customer Details"));
            }
        }

        public virtual BasePaymentPlanTab PaymentPlanTab
        {
            get
            {
                return Navigate.To<BasePaymentPlanTab>(By.LinkText("Payment Plan"));
            }
        }

        public virtual BasePaymentTab PaymentTab
        {
            get
            {
                return Navigate.To<BasePaymentTab>(By.LinkText("Payment"));
            }
        }

        public virtual BaseSignaturesTab SignaturesTab
        {
            get
            {
                return Navigate.To<BaseSignaturesTab>(By.LinkText("Signatures"));
            }
        }

        public virtual ContractTab_StandardNZ ContractTabStandardNz
        {
            get
            {
                return Navigate.To<ContractTab_StandardNZ>(By.LinkText("Contract"));
            }
        }


    }
}