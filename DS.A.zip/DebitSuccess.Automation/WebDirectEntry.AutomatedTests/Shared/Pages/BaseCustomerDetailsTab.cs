﻿using System.Threading;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using TestStack.Seleno.PageObjects;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class BaseCustomerDetailsTab : DirectEntryBasePage
    {

        public virtual BaseCustomerDetailsTab UpdateCustomerDetailsTab(BaseCustomerDetailsModel model)
        {
            Thread.Sleep(1000);
            Find.SendDirectEntryDataToForm(new
            {
                model.Gender,
                model.FirstName,
                model.LastName,
                model.DateOfBirth,
                model.MailingAddress,
                model.Suburb, 
                model.Postcode, 
                model.State,
                model.EmailAddress, 
                model.PhoneHome, 
                model.PhoneWork, 
                model.PhoneMobile, 
                model.PhoneEmergency, 
                model.EmergencyContactName,
                
            });
            Find.TakeTestScreenshot("Customer Details Page");
            return this;
        }

        public virtual T Next<T>() where T : Page, new()
        {
            return Navigate.To<T>(By.Id("btnSectionNextButtonCustomerDetailsEnabledBottom"));
        }
    }
}