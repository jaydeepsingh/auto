﻿using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using TestStack.Seleno.PageObjects;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class BasePaymentPlanTab : DirectEntryBasePage
    {
        public virtual string InstalmentAmount {
            set
            {
                Find.Element(By.CssSelector("div[key=InstalmentAmount] input[key=InstalmentAmount][type=number]")).ClearAndSendKey(value);
                Find.Element(By.CssSelector("div[key=InstalmentAmount] input[key=InstalmentAmount][type=number]")).SendKeys(Keys.Tab);
            }
        }

        public virtual BasePaymentPlanTab UpdatePaymentPlanTab(BasePaymentPlanModel model)
        {
            if (model.InstalmentAmount > 0)
            {
                InstalmentAmount = model.InstalmentAmount.ToString();
            }
            else
            {
                InstalmentAmount = "";
            }

           
            Find.SendDirectEntryDataToForm(new
            {
                model.TermType,
                model.TerminateAfterMinTerm,
                model.PaymentFrequency,
                model.CancellationFee,
               
                });
            if ((model.TermType).ToString() == "P")
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.MinimumTermPayments
                });
            }
            else
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.MinimumTermMonths
                });
            }
            if (model.FirstOneOff)
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.FirstOneOff,
                    model.AddOneOffPaymentOne.FirstOneOffAmount,
                    model.AddOneOffPaymentOne.FirstOneOffDesc,
                    model.AddOneOffPaymentOne.FirstOneOffDate
                });
            }
            if (model.SecondOneOff)
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.SecondOneOff,
                    model.AddOneOffPaymentTwo.SecondOneOffAmount,
                    model.AddOneOffPaymentTwo.SecondOneOffDesc,
                    model.AddOneOffPaymentTwo.SecondOneOffDate
                });
            }

            if (model.InstalmentAmount > 0) //can't fill some fields if instalment amount is not filled
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.FirstPaymentDate,
                    model.BillingFee
                });
            }
            Find.TakeTestScreenshot("Payment Plan Tab");
            return this;
        }

        public virtual BasePaymentPlanTab Initial()
        {
            Execute.Script("$('div[key=TerminateAfterMinTermInitials] .btn-warning').trigger('click')");
            Find.GetDriver().Sign();
           
            return this;
        }

        

        public virtual T Next<T>() where T : Page, new()
        {
            return Navigate.To<T>(By.Id("btnSectionNextButtonPaymentPlanEnabledBottom"));
        }
    }
}