﻿using System;
using System.Diagnostics;
using System.Linq;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using TestStack.Seleno.PageObjects;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Shared.Models;
using TestStack.BDDfy;
namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class BaseContractTab : DirectEntryBasePage
    {

        public virtual BaseContractTab UpdateContractTab(BaseContractModel model)
        {
           
           Find.SendDirectEntryDataToForm(new
            {
                BusinessAccount = model.DebitsuccessIdentifier,
                BusinessId = model.BusinessId,
                CustomerType = model.CustomerType

            });
            


            Find.TakeTestScreenshot("Contract Tab");
            return this;
        }


        public virtual T Next<T>() where T : Page, new()
        {
            return Navigate.To<T>(By.Id("btnSectionNextButtonContractEnabledBottom"));
        }



    }
}
