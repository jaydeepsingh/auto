﻿using System;
using System.Collections;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using DebitSuccess.Automation.Framework.Extensions;
using DebitSuccess.Automation.Framework.Fixtures;
using OpenQA.Selenium;
using WebDirectEntry.AutomatedTests.Extensions;
using TestStack.BDDfy;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class ConfirmationPage : DirectEntryBasePage
    {

        public virtual void ViewContract()
        {
            Find.Element(By.LinkText("View Contract"));
        }

        public virtual BaseCustomerDetailsTab ViewCustomerDetails()
        {
            return Navigate.To<BaseCustomerDetailsTab>(By.LinkText("View Customer Details"));
        }

        public virtual BaseTemplatesListPage SubmitANewContract()
        {
            return Navigate.To<BaseTemplatesListPage>(By.LinkText("View Contract"));
        }

        public bool RegistrationSuccessful()
        {
            Thread.Sleep(5000);
            return Execute.ScriptAndReturn<bool>("$('div.alert-success').is(':visible')");
        }


        public string RegistrationSuccessfulMessage()
        {

            Thread.Sleep(2000);

            string msgSuccess = (Find.Element(By.CssSelector("div[Class='alert alert-success']"))).Text;
            return msgSuccess;
        }

        public string ReadDebitSuccessId()
        {
            //ViewCustomerDetails();


            Thread.Sleep(2000);
            Find.Switchto("Debitsuccess - Detail");
            string Debitsuccessid = (Find.Element(By.CssSelector("h2[id='customer-name']"))).Text;
            Thread.Sleep(2000);
            Find.TakeTestScreenshot("Confirmation Page");
            Find.CloseTab("Debitsuccess - Detail");
            
            return Debitsuccessid;
            
        }

        
        

    }
        
}