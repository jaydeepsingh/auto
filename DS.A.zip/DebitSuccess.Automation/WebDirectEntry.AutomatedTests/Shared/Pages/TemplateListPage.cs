﻿using System.Collections.Generic;
using System.Data;
using System.Threading;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;

namespace WebDirectEntry.AutomatedTests.Shared.Pages
{
    public class BaseTemplatesListPage : DirectEntryBasePage
    {
        public virtual BaseTemplatesListPage Go()
        {
            return Navigate.To<BaseTemplatesListPage>(By.ClassName("btn btn-success"));
        }

        public virtual TemplateDetailsPage ClickTemplate(string templateName)
        {
            Thread.Sleep(2000);
            return Navigate.To<TemplateDetailsPage>(By.LinkText(templateName));
        }

        public virtual BaseContractTab ContractTab
        {
            get { return Navigate.To<BaseContractTab>(By.LinkText("Contract")); }
        }

        public virtual DataTable TemplatesOnTable
        {
            get
            {
                return Find.Table();
            }
        }


       public void AdministrationTab()
        {
            IWebElement menuElement=Find.Element(By.LinkText("Administration"));
            if (menuElement != null) menuElement.Click();
            Find.Element(By.LinkText("Business Settings")).Click();
            IWebElement businessAccount = Find.Element(By.PartialLinkText("DST1"));
            businessAccount.Click();
            Find.Element(By.CssSelector("a[id='tabForm_Optional']")).Click();


        }
    }
}