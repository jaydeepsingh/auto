﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DebitSuccess.Automation.Framework.Controls;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Models
{
    public class StandardNZTemplateDetailModel
    {
        public StandardNZContractModel ContractModel { get; set; }
        public StandardNZCustomerDetailsModel CustomerDetailsModel { get; set; }
        public StandardNZPaymentPlanModel PaymentPlanModel { get; set; }
        public StandardNZPaymentModel PaymentModel { get; set; }
        public BaseSignaturesModel SignaturesModel { get; set; }
    }
    public class StandardNZContractModel : BaseContractModel
    {
        public TransferType TransferType { get; set; }
        public string TransferDSId;
        public string TransferDSName;
    }
    public class StandardNZCustomerDetailsModel : BaseCustomerDetailsModel
    {
        public bool AcceptSpecialOffers;
        public bool AcceptElectronicCorrespondance;
    }

    public class StandardNZPaymentPlanModel : BasePaymentPlanModel
    {
       public int JoiningFee { get; set; }
    }
    public class StandardNZPaymentModel : BasePaymentModel
    {
      
    }


    [RadioButton]
    public enum TransferType
    {
        TransFac,
        TransDBCustomer
    }

}
