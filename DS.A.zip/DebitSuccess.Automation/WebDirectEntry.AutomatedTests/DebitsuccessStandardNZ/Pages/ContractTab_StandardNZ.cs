﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Models;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Pages
{
    public class ContractTab_StandardNZ : BaseContractTab
    {
        public override BaseContractTab UpdateContractTab(BaseContractModel model)
        {
            var StandardNZModel = (StandardNZContractModel)model;
            Find.SendDirectEntryDataToForm(new
            {
                BusinessAccount = model.DebitsuccessIdentifier,
                model.BusinessId,
                CustomerType=StandardNZModel.CustomerType
            });
            if ((StandardNZModel.CustomerType).ToString()=="TF")
            {
                Find.SendDirectEntryDataToForm(new
                {
                    StandardNZModel.TransferType,
                    StandardNZModel.TransferDSId,
                    StandardNZModel.TransferDSName
                });
            }
            Find.TakeTestScreenshot("Contract Tab");

            return this;

        }

        

    }
}
