﻿using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Models;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Pages
{
    public class CustomerDetailsTab_StandardNZ : BaseCustomerDetailsTab
    {
        public override BaseCustomerDetailsTab UpdateCustomerDetailsTab(BaseCustomerDetailsModel model)
        {
            var standardNzModel = (StandardNZCustomerDetailsModel)model;
           
            Find.SendDirectEntryDataToForm(new
            {
                model.Gender,
                model.FirstName,
                model.LastName,
                model.DateOfBirth,
                model.MailingAddress,
                model.Suburb,
                model.City,
                model.Postcode,
                model.EmailAddress,
                ConfirmEmailAddress = model.EmailAddress,
                model.PhoneHome,
                model.PhoneWork,
                model.PhoneMobile,
                model.PhoneEmergency,
                model.EmergencyContactName,
                standardNzModel.AcceptSpecialOffers,
                standardNzModel.AcceptElectronicCorrespondance

            });

            return this;
        }
    }
}
