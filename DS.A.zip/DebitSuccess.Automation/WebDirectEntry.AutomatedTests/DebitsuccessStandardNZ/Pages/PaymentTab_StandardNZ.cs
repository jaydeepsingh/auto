﻿using System.Threading;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Models;
using WebDirectEntry.AutomatedTests.Extensions;
using WebDirectEntry.AutomatedTests.Shared.Models;
using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Pages
{
    public class PaymentTab_StandardNZ : BasePaymentTab
    {
        public override BasePaymentTab UpdatePaymentTab(BasePaymentModel model)
        {
            var StandardNZModel = (StandardNZPaymentModel) model;
            Find.SendDirectEntryDataToForm(new { model.PaymentType });

            if (model.PaymentType == PaymentType.CC)
            {
                CreditCard = model.CreditCard;

            }
            else
            {
                Find.SendDirectEntryDataToForm(new
                {
                    model.BankAccountDetails.BankName,
                    model.BankAccountDetails.BankAccountName,
                    StandardNZModel.BankAccountDetails.BankAccountNumber
                });
            }

            EnableTAndCCheckBox();

            Thread.Sleep(1000); //needs some time for 'Accept Terms And Conditions' checkbox to be activated

            Find.SendDirectEntryDataToForm(new { AcceptTsAndCs = true });

            return this;
        }
    }
}
