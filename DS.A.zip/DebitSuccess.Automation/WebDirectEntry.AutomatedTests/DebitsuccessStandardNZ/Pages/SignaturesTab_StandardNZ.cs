﻿using WebDirectEntry.AutomatedTests.Shared.Pages;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Pages
{
    public class SignaturesTab_StandardNZ : BaseSignaturesTab
    {
        public override BaseSignaturesTab SignAll()
        {
            SignCustomer();
            SignJoint();
            return this;
        }
    }
}
