﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestStack.BDDfy;
using WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Models;
using WebDirectEntry.AutomatedTests.Shared.Models;

namespace WebDirectEntry.AutomatedTests.DebitsuccessStandardNZ.Data
{
    public class StandardNZTemplateData
    {
        private const string DateOfBirth = "19/07/1987";
        private static readonly string FirstPaymentDate = DateTime.Now.AddDays(1).ToString("dd/MM/yyyy");
        private static readonly DateTime TodaysDate = DateTime.Today.Date;
        private static readonly string OneOffFirstPaymentDate = TodaysDate.AddDays(2).ToString("dd/MM/yyyy");
        public static StandardNZTemplateDetailModel BaseStandardNZData = new StandardNZTemplateDetailModel
        
        {
            ContractModel = new StandardNZContractModel()
            {
                BusinessId = "Cust 111",
                CustomerType = CustomerType.TF,
                TransferType = TransferType.TransFac,
                TransferDSId = "Test DS ID",
                TransferDSName =  "Test Customer"
            },
            CustomerDetailsModel = new StandardNZCustomerDetailsModel()
            {
                Gender = GenderType.M,
                FirstName = "Testcase",
                LastName = "Wde",
                DateOfBirth = DateOfBirth,
                MailingAddress = "19 Queen Street",
                Suburb = "CBD",
                Postcode = "1010",
                State = State.NSW,
                City = "Auckland",
                EmailAddress = "Facility1@debitsuccess.com",
                PhoneHome = "091234567",
                PhoneWork = "098912345",
                PhoneMobile = "021021021",
                PhoneEmergency = "027027027",
                EmergencyContactName = "Mr Emergency",
                AcceptSpecialOffers = true,
                AcceptElectronicCorrespondance = true
            },
            PaymentPlanModel = new StandardNZPaymentPlanModel()
            {
                
                PaymentFrequency = PaymentFrequency.WK,
                InstalmentAmount = 100,
                BillingFee = 49,
                JoiningFee = 50,
                FirstPaymentDate = FirstPaymentDate,
                TermType = TermType.M,
                MinimumTermMonths = 12,
                MinimumTermPayments = 100,
                FirstOneOff = true,
                SecondOneOff = false,
                AddOneOffPaymentOne =
                    new BaseAddOneOffPaymentModelOne()
                    {
                        FirstOneOffAmount = 100,
                        FirstOneOffDesc = "First one-off payment added",
                        FirstOneOffDate = OneOffFirstPaymentDate
                    },
                AddOneOffPaymentTwo =
                    new BaseAddOneOffPaymentModelTwo()
                    {
                        SecondOneOffAmount = 100,
                        SecondOneOffDesc = "Second one-off payment added",
                        SecondOneOffDate = OneOffFirstPaymentDate
                    },
                TerminateAfterMinTerm = false,
                Initials = true,
                CancellationFee = 149,
                SuspensionFee = 50,
                SpecialConditions = "Special Condition!!!"

            },
            PaymentModel = new StandardNZPaymentModel()
            {
                PaymentType = PaymentType.CC,
                CreditCard =
                    new CreditCardModel
                    {
                        Name = "AT Test",
                        CreditCardType = CreditCardType.VI,
                        ExpiryMonth = "12",
                        ExpiryYear = "19",
                        FirstDigits = "4111",
                        SecondDigits = "1111",
                        ThirdDigits = "1111",
                        FourthDigits = "1111"
                    },
                BankAccountDetails =
                    new BankAccountModel
                    {
                        BankAccountName = "TestAccount",
                        BankAccountNumber = "031587005000000",
                        BankIdentifier = "123456",
                        BankName = "ASB"
                    },
                PreviewTermsAndConditionsButton = true,
                AcceptTermsAndConditionsCheckBox = true
            },
            SignaturesModel = new BaseSignaturesModel
            {
                SignCustomerButton = true,
                SignJointAccountHolderButton = true,
                SignWitnessButton = true
            }
        };

        public static BasePaymentModel PaymentModelBankAccount = new BasePaymentModel
        {
            PaymentType = PaymentType.BA,
            CreditCard =
                new CreditCardModel
                {
                    Name = "AT Test",
                    CreditCardType = CreditCardType.VI,
                    ExpiryMonth = "12",
                    ExpiryYear = "19",
                    FirstDigits = "4111",
                    SecondDigits = "1111",
                    ThirdDigits = "1111",
                    FourthDigits = "1111"
                },
            BankAccountDetails =
                new BankAccountModel
                {
                    BankAccountName = "TestAccount",
                    BankAccountNumber = "031587005000000",
                    BankIdentifier = "1234",
                    BankName = "ASB"
                },
            PreviewTermsAndConditionsButton = true,
            AcceptTermsAndConditionsCheckBox = true
        };
    }
}
