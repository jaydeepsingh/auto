﻿using DebitSuccess.Automation.Framework.Fixtures;
using OpenQA.Selenium.Remote;
using TestStack.Seleno.Configuration;

namespace WebDirectEntry.AutomatedTests
{
    public class WebDirectEntryApplication : Application
    {
        /// <summary>
        /// Log the self service application off
        /// Needs to be overriden in the test project
        /// </summary>
        /// <param name="host"></param>
        public override void Logoff(SelenoHost host)
        {
            var driver = host.Application.Browser as RemoteWebDriver;
            if (driver != null) driver.ExecuteScript("document.getElementById('logoutForm').submit()");
        }
    }
}
