﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using DebitSuccess.Automation.Framework.Controls;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using TestStack.BDDfy;
using TestStack.Seleno.PageObjects.Actions;
using WebDirectEntry.AutomatedTests.Shared.Data;

namespace WebDirectEntry.AutomatedTests.Extensions
{
    public static class DirectEntryBrowserExtensions
    {

        /// <summary>
        /// Send object model to the page inputs
        /// Match the element by PropertyName - Id (case insensitive)
        /// Works for textbox, textarea, dropdown and checkbox only
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="model">The model.</param>
        /// <param name="skipProperties">The skip properties.</param>
        public static void SendDirectEntryDataToForm(this IElementFinder finder, object model, params string[] skipProperties)
        {
            var properties = model.GetType().GetProperties();
            foreach (var property in properties)
            {
                var val = property.GetValue(model);
                if (val != null && !skipProperties.Contains(property.Name))
                {
                    if (property.PropertyType.GetCustomAttributes(typeof(DropdownAttribute), true).Any()) //dropdown
                    {
                        var element = finder.FindSelectByKeyCaseInsensitive(property.Name);
                        element.SetControlValue(val);
                    }
                    else if (property.PropertyType.GetCustomAttributes(typeof (RadioButtonAttribute), true).Any()) //radio button
                    {
                        var element = finder.FindRadioButtonByKey(property.Name, val.ToString());
                        element.Click();
                    }
                    else //other inputs
                    {
                        var element = finder.FindInputByKeyCaseInsensitive(property.Name);
                        element.SetControlValue(val);
                    }
                }
            }
        }

        /// <summary>
        /// Send object model to the page inputs
        /// Match the element by PropertyName - Text 
        /// Works for textbox and checkbox only
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="model">The model.</param>
        /// <param name="skipProperties">The skip properties.</param>

        public static void SendBusinessSettingsDataToForm(this IElementFinder finder, object model,
            params string[] skipProperties)
        {
            var properties = model.GetType().GetProperties();
            foreach (var property in properties)
            {
                var val = property.GetValue(model);
                if (val != null && !skipProperties.Contains(property.Name))
                {
                    foreach (IWebElement checkbox in finder.Elements(By.XPath("//input[@type='checkbox']")))
                    {
                        IWebElement parent = checkbox.GetParent();
                        bool stringEquals = String.Equals((Regex.Replace((parent.Text), @"\s", "")), property.Name,
                            StringComparison.OrdinalIgnoreCase);
                        if (stringEquals)
                        {
                            var element = checkbox;
                            element.SetControlValue(val);
                            break;
                        }
                    }
                    foreach (IWebElement control in finder.Elements(By.XPath("//div[@class='control-group ']")))
                    {
                        bool stringEqual = String.Equals((Regex.Replace((control.Text), @"\s", "")),
                                 property.Name, StringComparison.OrdinalIgnoreCase);
                        if (stringEqual)
                        {
                            IWebElement textbox = control.FindElement(By.CssSelector("div[class='controls'] input[type='text']"));
                            var element = textbox;
                            element.SetControlValue(val);
                            break;
                        }
                     }
                   }
                }
            }
        




        /// <summary>
        /// Finds the element by id case insensitive.
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static IWebElement FindSelectByKeyCaseInsensitive(this IElementFinder finder, string key)
        {
            var xPath = string.Format("//select[translate(@key, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')='{0}']", key.ToLower());
            var element = finder.Element(By.XPath(xPath));
            return element;
        }

        /// <summary>
        /// Finds the element by id case insensitive.
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static IWebElement FindInputByKeyCaseInsensitive(this IElementFinder finder, string key)
        {
            var xPath = string.Format("//input[translate(@key, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')='{0}']", key.ToLower());
            var element = finder.Element(By.XPath(xPath));
            return element;
        }

        /// <summary>
        /// Finds the RadioButton by key.
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static IWebElement FindRadioButtonByKey(this IElementFinder finder, string key, string value)
        {
            var element = finder.Element(By.CssSelector("div[key=" + key + "] input[value=" + value + "]"));
            return element;
        }

        /// <summary>
        /// Draw signature on the screen
        /// </summary>
        /// <param name="driver">The driver.</param>
        public static void Sign(this IWebDriver driver)
        {
            var builder = new Actions(driver);
            var canvas = driver.FindElement(By.ClassName("jSignature"));
            var coordinatesList = Signature.Coordinates();


            var draw = builder.MoveToElement(canvas, coordinatesList[0].X, coordinatesList[0].Y)
                    .ClickAndHold(canvas)
                    .MoveToElement(canvas, coordinatesList[1].X, coordinatesList[1].Y)
                    .Release(canvas);
            draw.Build().Perform();

            var elements = driver.FindElements(By.TagName("Button"));

            var saveButton = elements.FirstOrDefault(x => x.Text == "Save");
            if (saveButton != null) saveButton.Click();
        }

        /// <summary>
        /// Switch the focus to the new Page which has the title given as Parameter
        /// </summary>
        /// <param name="title"></param>
        public static void Switchto(this IElementFinder finder, string title)
        {
            var driver = finder.GetDriver();
            ReadOnlyCollection<string> windowHandles = driver.WindowHandles;
            string curtitle;
            foreach (string handle in windowHandles)
            {
                driver.SwitchTo().Window(handle);
                curtitle = driver.Title;
                if (curtitle == title)
                {
                    break;
                }
            }
        }
        //This method will close the Tab once the Title mathces with the parameter Title Value
        public static void CloseTab(this IElementFinder finder, string title)
        {
            var driver = finder.GetDriver();
            ReadOnlyCollection<string> windowHandles = driver.WindowHandles;
            string mainWindow = driver.WindowHandles.First();
            foreach (string handle in windowHandles)
            {
                driver.SwitchTo().Window(handle);
                string curtitle = driver.Title;
                if (curtitle == title)
                {
                    driver.SwitchTo().Window(handle).Close();
                    break;
                }

            }
            driver.SwitchTo().Window(mainWindow);

        }

        

    }
}
