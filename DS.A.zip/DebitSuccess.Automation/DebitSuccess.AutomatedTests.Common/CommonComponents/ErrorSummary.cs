﻿using System.Collections.Generic;
using System.Linq;
using Castle.Core.Internal;
using OpenQA.Selenium;
using TestStack.Seleno.PageObjects;

namespace DebitSuccess.AutomatedTests.Common.CommonComponents
{
    public class ErrorSummary : UiComponent
    {
        public string Message
        {
            get
            {
                return Find.Element(By.ClassName("validation-summary-errors")).Text;
            }
        }

        public List<string> ValidationErrorMessages
        {
            get
            {
                var errorMessages = Find.Elements(By.ClassName("msg-validation-error")).Select(e => e.Text).Where(x => !x.IsNullOrEmpty()).ToList();

                return errorMessages;
            }
        }
    }
}
