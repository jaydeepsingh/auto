﻿using System;
using DebitSuccess.Automation.Framework.Fixtures;
using TestStack.Seleno.PageObjects;
using Xunit;

namespace DebitSuccess.AutomatedTests.Common.Base
{
    public class BaseTest : IDisposable, IClassFixture<TestClassFixture>
    {
        public BaseTest(TestClassFixture testClassFixture)
        {
            TestClassFixture = testClassFixture;
            TestFixture.Instance.RegisterNamedInstance(TestClassFixture, GetType().Name);
            
        }

        /// <summary>
        /// Gets or sets the test class context.
        /// </summary>
        /// <value>
        /// The test class context.
        /// </value>
        protected TestClassFixture TestClassFixture { get; set; }

        /// <summary>
        /// Initilise the page object and navigate to the page
        /// </summary>
        /// <typeparam name="TPage">The type of the page.</typeparam>
        /// <param name="url">The URL.</param>
        /// <returns>
        /// the type of the page it's visiting
        /// </returns>
        public TPage GoTo<TPage>(string url="") where TPage : UiComponent, new()
        {
            return TestClassFixture.Host.NavigateToInitialPage<TPage>(url);
        }


        /// <summary>
        /// Log off from the app
        /// </summary>
        public void Logoff()
        {
            TestFixture.Instance.CurrentApplication.Logoff(TestClassFixture.Host);
            TestClassFixture.Properties.IsLoggedIn = false;
        }


        /// <summary>
        /// Tear Down logic here, runs at the end of every test method
        /// </summary>
        public void Dispose()
        {
            
        }
    }
}
