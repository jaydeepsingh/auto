﻿using System;
using System.Linq;
using Autofac;
using DebitSuccess.Automation.Framework.Setup;

namespace DebitSuccess.Automation.Framework.Fixtures
{
    /// <summary>
    /// Single test context that is shared between all tests
    /// Only put logic that needs in the entire test run here
    /// </summary>
    public sealed class TestFixture
    {
        public static TestFixture Instance = new TestFixture();
        private Application _application;
        private IContainer _container;

        static TestFixture()
        {
            BddfyConfig.ConfigureBddfyReport();
        }

        /// <summary>
        /// Gets the current application object created in the current test project. 
        /// </summary>
        /// <value>
        /// The current application.
        /// </value>
        public Application CurrentApplication
        {
            get { return _application ?? (_application = GetCurrentApplication()); }
        }


        /// <summary>
        /// Registers an instance into IoC container, can be replaced by just a collection, but since we could use IoC later
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="instance">The instance.</param>
        /// <param name="name">The name.</param>
        public void RegisterNamedInstance<T>(T instance, string name) where T : class
        {
            var builder = new ContainerBuilder();
            builder.RegisterInstance(instance).Named<T>(name);
            if (_container != null)
                builder.Update(_container);
            else
                _container = builder.Build();
        }

        /// <summary>
        /// Get the instance from IoC container
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        public T ResolveNamedInstance<T>(string name)
        {
            return _container.ResolveNamed<T>(name);
        }


        
        private Application GetCurrentApplication()
        {
            var type = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(a => a.GetTypes())
                .FirstOrDefault(t => t.IsSubclassOf(typeof (Application)));
            
            if (type == null) return null;
            var application = (Application)Activator.CreateInstance(type);
            return application;
        }

        

        ~TestFixture()
        {
            Dispose();
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }  
    }
}
