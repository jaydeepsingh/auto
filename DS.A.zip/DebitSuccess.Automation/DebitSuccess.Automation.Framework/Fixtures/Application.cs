﻿using TestStack.Seleno.Configuration;

namespace DebitSuccess.Automation.Framework.Fixtures
{
    /// <summary>
    /// Represents the current application under test
    /// Create a class in your test application which inherits from this clas and override the methods
    /// </summary>
    public abstract class Application
    {
        /// <summary>
        /// Log the current application off
        /// Needs to be overriden in the test project
        /// </summary>
        public virtual void Logoff(SelenoHost host){}
    }
}
