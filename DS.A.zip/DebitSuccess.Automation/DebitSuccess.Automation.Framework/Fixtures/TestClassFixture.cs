﻿using System;
using DebitSuccess.Automation.Framework.Setup;
using DebitSuccess.Automation.Framework.TestSettings;
using DebitSuccess.Automation.Framework.Utilities;
using TestStack.Seleno.Configuration;

namespace DebitSuccess.Automation.Framework.Fixtures
{
    /// <summary>
    /// Context that is shared by all the tests in the same class
    /// </summary>
    public class TestClassFixture : IDisposable
    {
        private SelenoHost _host;
        private dynamic _properties;

        /// <summary>
        /// Gets the Seleno host that drives the page.
        /// </summary>
        public SelenoHost Host
        {
            get { return _host ?? (_host = SelenoHostFactory.CreateHost()); }
        }

        /// <summary>
        /// A dynamic property bag where you can set properties when you need
        /// </summary>
        public dynamic Properties {
            get { return _properties ?? (_properties = new DynamicPropertyBag()); } 
        }

        /// <summary>
        /// Tear down code for the test class
        /// </summary>
        public void Dispose()
        {
            //Log off the app when all tests in a class is finished
            if (Properties.IsLoggedIn != null && Properties.IsLoggedIn)
            {
                TestFixture.Instance.CurrentApplication.Logoff(Host);
                Properties.IsLoggedIn = false;
            }


            if (!new Settings().KeepHostAlive && Host != null)
            {
                Host.Dispose();
            }
        }
    }
}
