﻿using System;

namespace DebitSuccess.Automation.Framework.Controls
{
    [AttributeUsage(AttributeTargets.Enum)]
    public class DropdownAttribute : Attribute
    {
    }

    [AttributeUsage(AttributeTargets.Enum)]
    public class RadioButtonAttribute : Attribute
    {
        
    }

   
}
