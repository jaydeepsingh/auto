﻿namespace DebitSuccess.Automation.Framework.Utilities
{
    public static class XPathLibrary
    {
        public static string ButtonOnRowWithText(string textOnRow, string buttonText)
        {
            return string.Format(@"//td[contains(., '{0}')]/..//button[@value='{1}']", textOnRow, buttonText);
        }

        public static string GetOneRowFromText(string textOnRow)
        {
            string s = string.Format(@"//tr[(td[1][contains(.,'{0}')])]", textOnRow);
            return s;
        }
    }
}
