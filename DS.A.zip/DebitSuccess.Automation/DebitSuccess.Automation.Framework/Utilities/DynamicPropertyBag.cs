﻿using System.Collections.Generic;
using System.Dynamic;
using System.Web.Mvc;

namespace DebitSuccess.Automation.Framework.Utilities
{
    public class DynamicPropertyBag : DynamicObject
    {
        protected ViewDataDictionary dictionary = new ViewDataDictionary();

        public ViewDataDictionary GetDictionary()
        {
            return dictionary;
        }

        public override IEnumerable<string> GetDynamicMemberNames()
        {
            return dictionary.Keys;
        }

        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            result = dictionary[binder.Name];	// Never throws; null if not present
            return true;
        }

        public override bool TrySetMember(SetMemberBinder binder, object value)
        {
            dictionary[binder.Name] = value;
            return true;
        }
    }
}
