﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using DebitSuccess.Automation.Framework.TestSettings;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Internal;
using TestStack.BDDfy;
using TestStack.Seleno.Extensions;
using TestStack.Seleno.PageObjects.Actions;

namespace DebitSuccess.Automation.Framework.Extensions
{
    public static class BrowserExtensions
    {

        /// <summary>
        /// Takes a screenshot.
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="filename">The filename.</param>
        
        public static void TakeTestScreenshot(this IElementFinder finder,  string filename)
        {
            
          finder.GetDriver().TakeTestScreenshot(filename);

         }

        

        /// <summary>
        /// Takes a screenshot.
        /// </summary>
        /// <param name="driver">The driver.</param>
        /// <param name="filename">The filename.</param>
        public static void TakeTestScreenshot(this IWebDriver driver, string filename)
        {
            try
            {
               var screenshot = ((ITakesScreenshot) driver).GetScreenshot();
               screenshot.SaveAsFile(Path.Combine(new Settings().ScreenshoPath,
                        string.Format("{0}-{1:yyyy_MM_dd-hh_mm_ss}.png", filename, DateTime.Now)), ImageFormat.Png);
            }
            catch (Exception ex)
            {
                //Do nothing for now if screenshot fails
            }
        }


       


        /// <summary>
        /// Gets the table on the page as a DataTable object
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <returns></returns>
        public static DataTable Table(this IElementFinder finder)
        {
            var driver = finder.GetDriver();
            driver.WaitForJQueryToLoad();

            var result = new DataTable();
            var rowCount = finder.Elements(By.XPath("//tr")).Count() - 1; //skip header
            if (rowCount < 1) return result;

            foreach (var th in finder.Elements(By.XPath("//th")).Select(x => x.Text))
            {
                result.Columns.Add(th);
            }

            for (var i=0; i<rowCount; i ++)
            {
                var cells = finder.Elements(By.XPath(string.Format("(//tr)[{0}]//td", i + 2))).Select(x => x.Text).ToArray();
                result.Rows.Add(cells);
            }
            return result;
        }

        /// <summary>
        /// Firsts the row for a table
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <returns></returns>
        public static List<string> FirstRow(this IElementFinder finder)
        {
            var driver = finder.GetDriver();
            driver.WaitForJQueryToLoad();

            var firstRow = finder.Elements(By.XPath("(//tr)[2]//td"))
                .Select(x => x.Text)
                .ToList();
            return firstRow;
        }



        /// <summary>
        /// Get the Parent of the current node
        /// </summary>
        /// <param name="node">The html input element.</param>
        
        public static IWebElement GetParent(this IWebElement node)
        {
            return node.FindElement(By.XPath(".."));
        }
        /// <summary>
        /// Clears the input box and send value
        /// </summary>
        /// <param name="element">The html input element.</param>
        /// <param name="text">The text.</param>
        public static void ClearAndSendKey(this IWebElement element, string text)
        {
            element.Clear();
            element.SendKeys(text);
        }

      
        /// <summary>
        /// Send object model to the page inputs
        /// Match the element by PropertyName - Id (case insensitive)
        /// Works for textbox, textarea, dropdown and checkbox only
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="model">The model.</param>
        /// <param name="skipProperties">The skip properties.</param>
        public static void SendModelToPage(this IElementFinder finder, object model, params string[] skipProperties)
        {
            var properties = model.GetType().GetProperties();
            foreach (var property in properties)
            {
                var val = property.GetValue(model);
                if (val != null && !skipProperties.Contains(property.Name))
                {
                    var element = finder.FindElementByIdCaseInsensitive(property.Name);
                    element.SetControlValue(val);
                }
            }
        }

        /// <summary>
        /// Returns an object with the matching input data on the page
        /// Match the element by PropertyName - Id (case insensitive)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="finder">The finder.</param>
        /// <returns></returns>
        public static T ModelFromPage<T>(this IElementFinder finder) where T : new()
        {
            T obj = new T();
            var properties = typeof(T).GetProperties();
            foreach (var property in properties)
            {
                var element = finder.FindElementByIdCaseInsensitive(property.Name);
                object value = null;
                if(property.PropertyType == typeof(string))
                    value = element.GetControlValueAs<string>();
                else if (property.PropertyType == typeof (bool))
                    value = element.GetControlValueAs<bool>();
                property.SetValue(obj, value);
            }
            return obj;
        }

        /// <summary>
        /// Finds the element by id case insensitive.
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public static IWebElement FindElementByIdCaseInsensitive(this IElementFinder finder, string id)
        {
            var xPath = string.Format("//*[translate(@id, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')='{0}']", id.ToLower());
            var element = finder.Element(By.XPath(xPath));
            return element;
        }

        /// <summary>
        /// Try to find an element and see if it exists
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="findExpression">The find expression.</param>
        /// <returns></returns>
        public static bool ElementExists(this IElementFinder finder, By findExpression)
        {
            var element = finder.OptionalElement(findExpression, TimeSpan.FromSeconds(10));
            return element != null;
        }

        /// <summary>
        /// Sets value to the UI controls
        /// Currently works for text input, select, checkbox and radio button
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetControlValue(this IWebElement element, object value)
        {
            var driver = (element as IWrapsDriver).WrappedDriver;

            // Added below code to make the elements visible during execution
            Actions actions = new Actions(driver);
            actions.MoveToElement(element).Perform();
            if (element.GetAttribute("type") == "text" || element.TagName == "textarea" || element.GetAttribute("type") == "password"
                || element.GetAttribute("type") == "email" || element.GetAttribute("type") == "tel" || element.GetAttribute("type") == "number")
            {
                element.ClearAndSendKey(value.ToString());
            }
            else if (element.TagName == "select")
            {
                element.SendKeys(value.ToString());
            }
            else if (element.GetAttribute("type") == "checkbox")
            {
                if (element.Selected != (bool)value)
                    element.Click();
            }
            else if (element.GetAttribute("type") == "radio")
            {
                
                var radioButton = driver.FindElement(By.XPath(string.Format("//input[@type='radio' and @value='{0}']", value)));
                radioButton.Click();
            }
        }

        /// <summary>
        /// Determines whether the specified text is on the page
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <param name="text">The text.</param>
        /// <returns></returns>
        public static bool PageContainsText(this IElementFinder finder, string text)
        {
            return finder.Element(By.TagName("body")).Text.Contains(text);
        }

        /// <summary>
        /// Gets the driver from element finder
        /// </summary>
        /// <param name="finder">The finder.</param>
        /// <returns></returns>
        /// <exception cref="System.Exception">Element not found.</exception>
        public static IWebDriver GetDriver(this IElementFinder finder)
        {
            var wrappedElement = finder.Element(By.TagName("body")) as IWrapsDriver;
            if(wrappedElement == null)
                throw new Exception("Element not found.");

            return wrappedElement.WrappedDriver;
        }

        

        /// <summary>
        /// Waits for ajax to finish.
        /// </summary>
        /// <param name="driver">The driver.</param>
        public static void WaitForJQueryToLoad(this IWebDriver driver)
        {
            while (true) 
            {
                var ajaxIsComplete = (bool)(driver as IJavaScriptExecutor).ExecuteScript("return (typeof jQuery !== 'undefined') && jQuery.active == 0");
                if (ajaxIsComplete)
                    break;
                Thread.Sleep(100);
            }
        }

        

    }
}
