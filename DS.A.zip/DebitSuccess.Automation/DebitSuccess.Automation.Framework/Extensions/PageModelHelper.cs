﻿using OpenQA.Selenium;
using TestStack.Seleno.Extensions;
using TestStack.Seleno.PageObjects.Actions;

namespace DebitSuccess.Automation.Framework.Extensions
{
    public static class PageModelHelper
    {
        
    }
}
