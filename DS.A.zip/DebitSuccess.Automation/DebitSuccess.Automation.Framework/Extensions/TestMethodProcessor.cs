﻿using System;
using System.Linq;
using DebitSuccess.Automation.Framework.Fixtures;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.Events;
using TestStack.BDDfy;
using TestStack.Seleno.PageObjects.Actions;

namespace DebitSuccess.Automation.Framework.Extensions
{
    /// <summary>
    /// Runs at the end of a test method, you can use it to process Story, build report, process exception, and etc
    /// You can plug multiple classes with different ProcessType to the test result processor pipeline to do differnt things in order
    /// </summary>
    public class TestMethodProcessor : IProcessor
    {
        public void Process(Story story)
        {
            var scenario = story.Scenarios.First();
            
            /*if (scenario.Result == Result.Failed)
            {
               var testClassFixture = TestFixture.Instance.ResolveNamedInstance<TestClassFixture>(story.Metadata.Type.Name);
               testClassFixture.Host.Application.Browser.TakeTestScreenshot("FailedTest");

                
            }*/

        }

        public ProcessType ProcessType
        {

           get { return ProcessType.Report; }
            
        }

        

    }

   
}
