﻿using System.Collections.Generic;
using TestStack.BDDfy;

namespace DebitSuccess.Automation.Framework.Extensions
{
    /// <summary>
    /// Runs after all tests have finished and process the stories to generate a report 
    /// Excel report in this case
    /// </summary>
    public class ExcelTestReport : IBatchProcessor
    {
        public void Process(IEnumerable<Story> stories)
        {
            
        }
    }
}
