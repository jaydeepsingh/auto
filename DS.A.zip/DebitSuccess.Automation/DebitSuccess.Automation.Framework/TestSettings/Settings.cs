﻿using System.Configuration;

namespace DebitSuccess.Automation.Framework.TestSettings
{
    public class Settings
    {
        public string WebsiteUrl
        {
            get { return Get("WebsiteUrl"); }
        }

        public string ApplicationName
        {
            get { return Get("ApplicationName"); }
        }


        public string Browser
        {
            get { return Get("Browser"); }
        }

        public int Delay
        {
            get { return int.Parse(Get("Delay")); }
        }

        public string ReportPath
        {
            get { return Get("ReportPath"); }
        }

        public string ScreenshotPath
        {
            get { return Get("ScreenshotPath"); }
        }

        public string EmailSender
        {
            get { return Get("EmailSender"); }
        }

        public string EmailReceiver
        {
            get { return Get("EmailReceiver"); }
        }

        public string EmailServerHost
        {
            get { return Get("EmailServerHost"); }
        }

        public int EmailServerPort
        {
            get { return int.Parse(Get("EmailServerPort")); }
        }

        public bool KeepHostAlive
        {
            get { return bool.Parse(Get("KeepHostAlive")); }
        }

        public bool MaximizeBrowser
        {
            get { return bool.Parse(Get("MaximizeBrowser")); }
        }

        public int MinWaitTime
        {
            get { return int.Parse(Get("MinWaitTime")); }
        }

        public int MaxWaitTime
        {
            get { return int.Parse(Get("MaxWaitTime")); }
        }

        public string ScreenshoPath
        {
            get { return Get("ScreenshotPath"); }
        }

        private string Get(string key)
        {
            return ConfigurationManager.AppSettings[key];
        }
    }
}
