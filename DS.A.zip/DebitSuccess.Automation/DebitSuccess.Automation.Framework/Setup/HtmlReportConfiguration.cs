﻿using DebitSuccess.Automation.Framework.TestSettings;
using TestStack.BDDfy.Reporters.Html;

namespace DebitSuccess.Automation.Framework.Setup
{
    /// <summary>
    /// Bddfy report customisation
    /// </summary>
    public class HtmlReportConfiguration : DefaultHtmlReportConfiguration
    {
        private readonly Settings _settings;

        public HtmlReportConfiguration(Settings settings)
        {
            _settings = settings;
        }

        public override string OutputFileName
        {
            get
            {
                return string.Format("{0}.html", _settings.ApplicationName.Replace(" ", ""));
            }
        }

        public override string ReportHeader
        {
            get
            {
                return string.Format("Testing result for {0}", _settings.ApplicationName);
            }
        }

        public override string ReportDescription
        {
            get { return "Automated testing using Bddfy and Seleno"; }
        }

        public override string OutputPath
        {
            get { return _settings.ReportPath; }
        }
    }
}
