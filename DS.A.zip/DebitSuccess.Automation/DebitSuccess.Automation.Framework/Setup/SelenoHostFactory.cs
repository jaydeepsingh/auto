﻿using System;
using DebitSuccess.Automation.Framework.TestSettings;
using TestStack.Seleno.Configuration;
using TestStack.Seleno.Configuration.WebServers;

namespace DebitSuccess.Automation.Framework.Setup
{
    public class SelenoHostFactory
    {
        public static SelenoHost CreateHost()
        {
            var host = new SelenoHost();
            try
            {
                var settings = new Settings();
                host.Run(x => x.WithWebServer(new InternetWebServer(settings.WebsiteUrl))
                    .WithRemoteWebDriver(DriverFactory.Create)
                    .UsingCamera(settings.ScreenshoPath)
                    .WithMinimumWaitTimeoutOf(TimeSpan.FromSeconds(settings.MinWaitTime)));
                return host;
            }
            catch (Exception)
            {
                host.Dispose();
                throw;
            }
        }
    }
}
