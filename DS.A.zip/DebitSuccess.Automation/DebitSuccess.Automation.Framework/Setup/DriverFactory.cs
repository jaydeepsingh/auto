﻿using DebitSuccess.Automation.Framework.TestSettings;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using TestStack.Seleno.Configuration;
using TestStack.Seleno.Extensions;

namespace DebitSuccess.Automation.Framework.Setup
{
    public class DriverFactory
    {
        public static RemoteWebDriver Create()
        {
            RemoteWebDriver driver;
            var settings = new Settings();
            if (settings.Browser == "Firefox")
            {
                driver = GetFirefoxDriver();
            }
            else
            {
                driver = GetChromeDriver();
            }
            if (settings.MaximizeBrowser) driver.MaximizeWindow();
            return driver;
        }

        private static ChromeDriver GetChromeDriver()
        {
            return BrowserFactory.Chrome();
        }

        private static FirefoxDriver GetFirefoxDriver()
        {
            return BrowserFactory.FireFox();
        }
    }
}
