﻿using DebitSuccess.Automation.Framework.Extensions;
using DebitSuccess.Automation.Framework.TestSettings;
using TestStack.BDDfy.Configuration;
using TestStack.BDDfy.Reporters.Html;

namespace DebitSuccess.Automation.Framework.Setup
{
    /// <summary>
    /// Bddfy Configurations
    /// </summary>
    public static class BddfyConfig
    {
        public static void ConfigureBddfyReport()
        {
            var settings = new Settings();
            Configurator.BatchProcessors.MarkDownReport.Enable();
            Configurator.BatchProcessors.DiagnosticsReport.Enable();
            Configurator.BatchProcessors.HtmlReport.Disable();
            Configurator.BatchProcessors.Add(new HtmlReporter(new HtmlReportConfiguration(settings)));
            Configurator.BatchProcessors.Add(new ExcelTestReport());
            Configurator.Processors.Add(() => new TestMethodProcessor());
        }
    }
}
