﻿using DebitSuccess.AutomatedTests.Common.CommonComponents;
using FluentAssertions;

namespace SelfService.AutomatedTests.Shared
{
    public static class SharedSteps
    {
        /// <summary>
        /// Error mesasge on validation summary element
        /// </summary>
        /// <param name="errorComponent">The error component.</param>
        /// <param name="message">The message.</param>
        public static void ThenIShouldSeeTheErrorMessage(ErrorSummary errorComponent, string message)
        {
            errorComponent.Message.Should().Contain(message);
        }
    }
}
