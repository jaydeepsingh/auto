﻿using DebitSuccess.AutomatedTests.Common.CommonComponents;
using SelfService.AutomatedTests.Customers.Components;
using TestStack.Seleno.PageObjects;

namespace SelfService.AutomatedTests.Shared
{
    /// <summary>
    /// Put the page common logic here, or not
    /// </summary>
    public class SelfServiceBasePage : Page
    {

        /// <summary>
        /// Error summary at the top of a page
        /// </summary>
        public ErrorSummary ErrorMessageComponent {get { return GetComponent<ErrorSummary>(); }}

        /// <summary>
        /// Menu bar at the top of the page
        /// </summary>
        public TopMenuBar MenuBar { get { return GetComponent<TopMenuBar>(); } }
    }


}
