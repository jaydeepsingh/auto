﻿using TestStack.Seleno.PageObjects;

namespace SelfService.AutomatedTests.Shared
{
    /// <summary>
    /// Represents the menu bar at the top of the page
    /// </summary>
    public class TopMenuBar : UiComponent
    {

    }
}
