IF EXISTS(
    SELECT * 
    FROM sys.databases 
    WHERE name = 'Snapshot_DSELK_Dev' 
    AND source_database_id IS NOT NULL
)
DROP DATABASE Snapshot_DSELK_Dev;
PRINT 'Snapshot dropped..'
GO

CREATE DATABASE Snapshot_DSELK_Dev
ON
(NAME=DSElk_Extended_Web_Services, FILENAME='D:\Snapshot_DSELK_Dev.ss')
AS SNAPSHOT OF DSElk_Extended_Web_Services

PRINT 'Snapshot created..'