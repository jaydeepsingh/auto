﻿using DebitSuccess.Automation.Framework;
using DebitSuccess.Automation.Framework.Fixtures;
using OpenQA.Selenium.Remote;
using TestStack.Seleno.Configuration;

namespace SelfService.AutomatedTests
{
    public class SelfServiceApplication : Application
    {
        /// <summary>
        /// Log the self service application off
        /// Needs to be overriden in the test project
        /// </summary>
        /// <param name="host"></param>
        public override void Logoff(SelenoHost host)
        {
            var driver = host.Application.Browser as RemoteWebDriver;
            driver.ExecuteScript("document.getElementById('logoutForm').submit()");
        }
    }
}
