﻿using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using SelfService.AutomatedTests.Customers.Pages;
using SelfService.AutomatedTests.Shared;

namespace SelfService.AutomatedTests.Login
{
    public class LoginPage : SelfServiceBasePage
    {

        public CustomersListPage LoginWithUser(LoginModel user)
        {
            Find.SendModelToPage(user);

            return Navigate.To<CustomersListPage>(By.CssSelector(".btn[type=submit]")); 
        }

    }
}
