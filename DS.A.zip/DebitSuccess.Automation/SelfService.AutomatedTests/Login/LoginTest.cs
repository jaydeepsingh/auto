﻿using DebitSuccess.AutomatedTests.Common.Base;
using DebitSuccess.Automation.Framework.Fixtures;
using FluentAssertions;
using SelfService.AutomatedTests.Customers.Data;
using SelfService.AutomatedTests.Customers.Pages;
using SelfService.AutomatedTests.Shared;
using TestStack.BDDfy;
using Xunit;

namespace SelfService.AutomatedTests.Login
{
    [Story(AsA = "As a Web Portal User", 
           IWant = "I want to be able to log into the Self Service website", 
           SoThat ="So that I can manage facility customers")]
    public class LoginTest : BaseTest
    {
        private LoginPage _loginPage;
        private CustomersListPage _customerListPage;

        public LoginTest(TestClassFixture fixture)
            : base(fixture)
        {
        }

        [Fact]
        public void LoginShouldBeSuccessfulIfCorrectCredentialIsEntered()
        {
            this.Given(x => GivenIAmOnTheLoginScreen())
                .When(x => WhenILoginAsUser(LoginData.OmgdemoUser), string.Format("When I login as {0},{1}", LoginData.OmgdemoUser.CompanyId, LoginData.OmgdemoUser.UserName))
                .Then(x => ThenIShouldBeOnCustomersPage())
                .BDDfy();
        }

        [Fact]
        public void LoginShouldFailIfInvalidPasswordIsEntered()
        {
            this.Given(x => GivenIAmOnTheLoginScreen())
                .When(x => WhenILoginWithWrongCredential(LoginData.UserWithWrongPass), "When I login with a wrong password")
                .Then(x => SharedSteps.ThenIShouldSeeTheErrorMessage(_loginPage.ErrorMessageComponent, LoginData.LoginPermissionError), false)
                .BDDfy();
        }


        private void GivenIAmOnTheLoginScreen()
        {
            if (TestClassFixture.Properties.IsLoggedIn != null && TestClassFixture.Properties.IsLoggedIn)
            {
                Logoff();
            }
            _loginPage = GoTo<LoginPage>();
        }

        private void WhenILoginAsUser(LoginModel user)
        {
            _customerListPage = _loginPage.LoginWithUser(user);
            TestClassFixture.Properties.IsLoggedIn = true;
        }

        private void WhenILoginWithWrongCredential(LoginModel login)
        {
            _loginPage.LoginWithUser(login);
        }

        private void ThenIShouldBeOnCustomersPage()
        {
            _customerListPage.Title.Should().Be(CustomerData.CustomerListPageTitle);
        }


        public CustomersListPage GivenIHaveLoggedInAs(LoginModel user)
        {
            if (TestClassFixture.Properties.IsLoggedIn != null && TestClassFixture.Properties.IsLoggedIn) 
                return GoTo<CustomersListPage>(); //already logged in

            GivenIAmOnTheLoginScreen();
            WhenILoginAsUser(user);

            return GoTo<CustomersListPage>(); 
        }

        
    }

    
}
