﻿namespace SelfService.AutomatedTests.Login
{
    public class LoginData
    {
        public static LoginModel OmgdemoUser = new LoginModel()
        {
            CompanyId = "omgdemo",
            UserName = "master",
            Password = "Passw0rd"
        };

        public static LoginModel UserWithWrongPass = new LoginModel()
        {
            CompanyId = "omgdemo",
            UserName = "master",
            Password = "xyz"
        };

        public static string LoginPermissionError = "The supplied credentials are either insufficient or incorrect. Please try again.";
    }

    public class LoginModel
    {
        public string CompanyId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
