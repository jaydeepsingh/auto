﻿using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using SelfService.AutomatedTests.Customers.Data;
using SelfService.AutomatedTests.Customers.Pages;
using TestStack.Seleno.Extensions;
using TestStack.Seleno.PageObjects;

namespace SelfService.AutomatedTests.Customers.Components
{
    public class CustomerSearchPanel : UiComponent
    {
        public string FirstName
        {
            get { return Find.Element(By.Id("firstNameSearch")).GetControlValueAs<string>(); }
            set { Find.Element(By.Id("firstNameSearch")).ClearAndSendKey(value); }
        }

        public string LastName
        {
            get { return Find.Element(By.Id("lastNameSearch")).GetControlValueAs<string>(); }
            set { Find.Element(By.Id("lastNameSearch")).ClearAndSendKey(value); }
        }

        public string ReferenceNumber
        {
            get { return Find.Element(By.Id("referenceNoSearch")).GetControlValueAs<string>(); }
            set { Find.Element(By.Id("referenceNoSearch")).ClearAndSendKey(value); }
        }


        public CustomersListPage Go()
        {
            var page = Navigate.To<CustomersListPage>(By.XPath("//button[contains(.,'Go')]"));
            WaitFor.AjaxCallsToComplete();
            return page;
        }

        public void Reset()
        {
            Find.Element(By.CssSelector("button[type=reset]")).Click();
        }

        public CustomersListPage PerformSearch(SearchModel model)
        {
            FirstName = model.FirstName;
            LastName = model.LastName;
            ReferenceNumber = model.ReferenceNumber;

            return Go();
        }
    }
}
