﻿using System.Collections.Generic;
using System.Linq;
using DebitSuccess.AutomatedTests.Common.Base;
using DebitSuccess.Automation.Framework.Fixtures;
using FluentAssertions;
using SelfService.AutomatedTests.Customers.Data;
using SelfService.AutomatedTests.Customers.Pages;
using SelfService.AutomatedTests.Login;
using TestStack.BDDfy;
using Xunit;

namespace SelfService.AutomatedTests.Customers.Tests
{
    [Story(AsA = "As a Self Service User",
           IWant = "I want to be able to search customer",
           SoThat = "So that I can manage information of specific customers")]
    public class SearchCustomerTests : BaseTest
    {
        private CustomersListPage _customersListPage;

        public SearchCustomerTests(TestClassFixture testClassFixture)
            : base(testClassFixture)
        {
        }

        [Fact]
        public void ClickGoWithoutEnteringSearchCriteriaShouldReturnAListOfCustomers()
        {
            this.Given(x => x.GivenIAmOnTheCustomersListPage())
                .When(x => x.WhenIResetTheSearch())
                .And(x => x.WhenIClickGoButtonOnTheSearchPanel())
                .Then(x => x.ThenIShouldSeeAListOfCustomers(CustomerData.CustomersPerPage), "Then I should see {0} customers on the page")
                .BDDfy();
        }

        [Fact]
        public void EnterNameAndReferenceNumberInSearchBoxShouldReturnCorrectCustomer()
        {
            this.Given(x => x.GivenIAmOnTheCustomersListPage())
                .When(x => x.WhenISearchForACustomer(CustomerData.TestCustomer), false)
                .Then(x => x.ThenIShouldSeeTheSearchResult(new List<SearchModel> { CustomerData.TestCustomer }), false)
                .BDDfy();
        }

        

        private void GivenIAmOnTheCustomersListPage()
        {
            _customersListPage = new LoginTest(TestClassFixture).GivenIHaveLoggedInAs(LoginData.OmgdemoUser);
        }

        private void WhenIResetTheSearch()
        {
            _customersListPage.SearchPanel.Reset();
        }

        private void WhenISearchForACustomer(SearchModel search)
        {
            _customersListPage.SearchPanel.PerformSearch(search);
        }

        private void WhenIClickGoButtonOnTheSearchPanel()
        {
            _customersListPage = _customersListPage.SearchPanel.Go();
        }

        private void ThenIShouldSeeAListOfCustomers(int numberOfCustomers)
        {
            _customersListPage.CustomersCount.Should().Be(numberOfCustomers);
        }

        private void ThenIShouldSeeTheSearchResult(List<SearchModel> result)
        {
            var customersTable = _customersListPage.CustomersOnPage;
            bool matchedAll = result.Select((t, i) => 
                customersTable.Rows[i]["Name"].ToString().Contains(t.FirstName) && //match first name
                customersTable.Rows[i]["Name"].ToString().Contains(t.LastName) && //match last name
                customersTable.Rows[i]["Debitsuccess ID"].ToString().Contains(t.ReferenceNumber)) //match reference no.
                .All(matchedRow => matchedRow);
            matchedAll.Should().BeTrue();
        }

    }
}
