﻿using System;
using System.Data;
using System.Linq;
using DebitSuccess.AutomatedTests.Common.Base;
using DebitSuccess.Automation.Framework.Fixtures;
using FluentAssertions;
using SelfService.AutomatedTests.Customers.Data;
using SelfService.AutomatedTests.Customers.Pages;
using SelfService.AutomatedTests.Login;
using TestStack.BDDfy;
using Xunit;

namespace SelfService.AutomatedTests.Customers.Tests
{
    [Story(AsA = "As a Self Service User",
           IWant = "I want to be able to use the Variation feature",
           SoThat ="So that I can change customer info")]
    public class CustomerVariationTests : BaseTest
    {
        private CustomerDetailsPage _customerDetailsPage;
        private CustomerVariationPage _customerVariationPage;
        private UpdateCustomerPage _updateNamePage;
        private BusinessIdPage _businessIdPage;
        private AddCallNotePage _addCallNotePage;
        private AddressesPage _addressesPage;

        public CustomerVariationTests(TestClassFixture testSetup) : base(testSetup)
        {
        }

        [Fact]
        public void UpdateCustomerName()
        {
            this.Given(x => x.GivenIAmOnVariationTabUpdateNamePage(CustomerData.TestCustomer), false)
                .When(x => x.WhenIUpdateTheCustomerName(CustomerData.CustomerForUpateName), false)
                .Then(x => x.ThenTheCustomerNameShouldBeUpdated(CustomerData.CustomerForUpateName), false)
                .BDDfy();
        }

        [Fact]
        public void UpdateBusinessId()
        {
            this.Given(x => x.GivenIAmOnVariationTabBusinessIdPage(CustomerData.TestCustomer), false)
                .When(x => x.WhenIUpdateTheBusinessId(CustomerData.BusinessIdForUpdate), false)
                .Then(x => x.ThenTheBusinessIdShouldBeUpdated(CustomerData.BusinessIdForUpdate), false)
                .BDDfy();
        }

        [Fact]
        public void AddCallNote()
        {
            this.Given(x => x.GivenIAmOnVariationTabAddCallNotePage(CustomerData.TestCustomer), false)
                .When(x => x.WhenIAddCallNote(CustomerData.CallNoteToAdd), false)
                .Then(x => x.ThenIShouldBeAbleToSeeTheCallNoteInCallHistoryTab(CustomerData.CallNoteToAdd), false)
                .BDDfy();
        }

        //[Fact]
        public void AddNewAddress()
        {
            var addressType = default(AddressType);
            var customer = default(SearchModel);
            this.Given(x => x.GivenIAmOnVariationTabAddressesPage(customer), "Given I am on variation tab addresses page")
                .When(x => x.WhenIAmOnTheAddAddressPage())
                .And(x => x.AndISelectNzAsCountry())
                .Then(x => x.ThenStateShouldBecomeInvisible())
                .When(x => x.WhenIAddAnAddress(addressType, CustomerData.NewAddress), "When I add a new address with the following address types")
                .Then(x => x.ThenIShouldBeAbleToSeeTheNewAddress(addressType, CustomerData.NewAddress), false)
                .WithExamples(new ExampleTable("Address Type", "Customer")
                {
                   {AddressType.Business, CustomerData.TestCustomer},
                   {AddressType.Physical, CustomerData.TestCustomer},
                   {AddressType.Home, CustomerData.TestCustomer},
                   {AddressType.Postal, CustomerData.CustomerForAddPostalAddress}, //use another customer since one customer needs to have an account
                })
                .BDDfy();
        }

        //[Fact]
        public void EditAddress()
        {
            var addressType = default(AddressType);
            var customer = default(SearchModel);
            this.Given(x => x.GivenIAmOnVariationTabAddressesPage(CustomerData.CustomerForEditAddress), false)
                .When(x => x.WhenIEditAnAddress(addressType, CustomerData.UpdateAddress), "When I edit an address with the following address types")
                .Then(x => x.ThenIShouldBeAbleToSeeTheNewAddress(addressType, CustomerData.UpdateAddress), false)
                .WithExamples(new ExampleTable("Address Type")
                {
                   AddressType.Business,
                   AddressType.Physical,
                   AddressType.Home,
                   AddressType.Postal, 
                })
                .BDDfy();
        }


        #region Update Customer Name
        private void GivenIAmOnVariationTabUpdateNamePage(SearchModel customer)
        {
            _updateNamePage = GoToCustomerDetailsPage(customer)
                .VariationTab
                .UpdateCustomerTab;
        }

        private void WhenIUpdateTheCustomerName(CustomerNameModel customer)
        {
            _customerVariationPage = _updateNamePage.UpdateCustomerName(customer);
        }

        private void ThenTheCustomerNameShouldBeUpdated(CustomerNameModel customer)
        {
            var updatedCustomer = _customerVariationPage.UpdateCustomerTab.Customer;
            updatedCustomer.FirstName.Should().Be(customer.FirstName);
            updatedCustomer.MiddleName.Should().Be(customer.MiddleName);
            updatedCustomer.LastName.Should().Be(customer.LastName);
        }

        #endregion

        #region Update Business Id
        private void GivenIAmOnVariationTabBusinessIdPage(SearchModel customer)
        {
            _businessIdPage = GoToCustomerDetailsPage(customer)
                .VariationTab
                .BusinessIdTab;
        }

        private void WhenIUpdateTheBusinessId(BusinessIdModel model)
        {
            _customerVariationPage = _businessIdPage.UpdateBusinessId(model);
        }

        private void ThenTheBusinessIdShouldBeUpdated(BusinessIdModel model)
        {
            _businessIdPage.UpdatedBusinessId.BusinessId.Should().Be(model.BusinessId);
        }
        #endregion

        #region Add Call Note
        private void GivenIAmOnVariationTabAddCallNotePage(SearchModel customer)
        {
            _customerDetailsPage = GoToCustomerDetailsPage(customer);
            _addCallNotePage = _customerDetailsPage
                .VariationTab
                .AddCallNoteTab;
        }

        private void WhenIAddCallNote(string note)
        {
            _customerVariationPage = _addCallNotePage.AddNote(note);
        }

        private void ThenIShouldBeAbleToSeeTheCallNoteInCallHistoryTab(string note)
        {
            var lastCallNote = _customerDetailsPage.CallHistoryTab.LastCallNote;
            lastCallNote.Any(x => x.Contains(note)).Should().BeTrue();
        }
        #endregion

        #region Add/Edit Address
        private void GivenIAmOnVariationTabAddressesPage(SearchModel customer)
        {
            _addressesPage = GoToCustomerDetailsPage(customer)
                .VariationTab
                .AddressesTab;
        }

        private void WhenIAmOnTheAddAddressPage()
        {
            _addressesPage = _addressesPage.GoAddAddress();
        }

        private void AndISelectNzAsCountry()
        {
            _addressesPage.Country = "NewZealand";
        }

        private void ThenStateShouldBecomeInvisible()
        {
            _addressesPage.IsStateVisible.Should().BeFalse();
        }

        private void WhenIAddAnAddress(AddressType addressType, AddressModel model)
        {
            model.AddressType = addressType.ToString();
            _customerVariationPage = _addressesPage.AddAddress(model);
        }

        private void ThenIShouldBeAbleToSeeTheNewAddress(AddressType addressType, AddressModel model)
        {
            var addressTable = _customerVariationPage.AddressesTab.AddressesOnPage;
            var matchFound = addressTable.Rows.Cast<DataRow>().Any(row => 
                row["Type"].ToString() == addressType.ToString() && 
                row["Address"].ToString().Contains(model.Address1) && 
                row["Address"].ToString().Contains(model.Suburb) && 
                row["Address"].ToString().Contains(model.City));
            matchFound.Should().BeTrue();
        }


        private void WhenIEditAnAddress(AddressType addressType, AddressModel model)
        {
            model.AddressType = addressType.ToString();
            _customerVariationPage = _addressesPage.GoEditAddress(addressType).EditAddress(model, "AusState");
        }


        #endregion

        private CustomerDetailsPage GoToCustomerDetailsPage(SearchModel customer)
        {
            return new LoginTest(TestClassFixture)
                .GivenIHaveLoggedInAs(LoginData.OmgdemoUser)
                .SearchPanel
                .PerformSearch(customer)
                .SelectCustomerByReferenceNumber(customer.ReferenceNumber);
        }
    }
}
