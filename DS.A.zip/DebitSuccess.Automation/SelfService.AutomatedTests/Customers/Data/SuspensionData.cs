﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfService.AutomatedTests.Tests_by_whit.TestData
{
    public class SuspensionData
    {
        public static SuspensionModel generateModelAfterLastDate(string lastDate)
        {
            var model = new SuspensionModel();
            DateTime dt = Convert.ToDateTime(lastDate).AddDays(1);
            string startDate = dt.ToString("d/MM/yyyy");
            DateTime maxDate=new DateTime(2025,12,31);
            int range = 60;
            Random random = new Random();

            string endDate = dt.AddDays(random.Next(range)).ToString("d/MM/yyyy");

            model.StartDate = startDate;
            model.EndDate = endDate;

            return model;
        }

        public class suspension:SuspensionModel
        {
            private static DateTime date = DateTime.Today.Date.AddDays(1);
            private string _startDate = date.ToString("d/MM/yyyy");
            private static DateTime maxDate = new DateTime(2025,12,31);
            private static int range = 60;
            private static Random random = new Random();

            private string _endDate = date.AddDays(random.Next(range)).ToString("d/MM/yyyy");

            private string _amount = "20";

            private string _suspensionReason = "nothing";

            public override string StartDate
            {
                get{return _startDate;}
                set { _startDate = value; }
            }
            public override string EndDate
            {
                get { return _endDate; }
                set { _endDate = value; }

            }

            public override string Amount
            {
                get { return _amount; }
                set { _amount = value; }
            }

            public override string SuspensionReason
            {
                get { return _suspensionReason; }
                set { _suspensionReason = value; }
            }
        }
    }
}
