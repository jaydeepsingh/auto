﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfService.AutomatedTests.Tests_by_whit.TestData
{
    public class AddCallNoteData
    {
        public static string CallNoteToAdd = "Self Service Automation Test Call Note";
    }
}
