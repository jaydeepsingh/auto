﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SelfService.AutomatedTests.Tests_by_whit.Model;

namespace SelfService.AutomatedTests.Tests_by_whit.TestData
{
    public class ContactData
    {
        public static CustomerContactModel randomFromEmail = new CustomerContactModel()
        {
            Detail = "65868576876"
        };

        public static CustomerContactModel randomForEmail = new CustomerContactModel()
        {
            Detail = "linda@gmail.com"
        };

        public static CustomerContactModel contactModelForEmail = new CustomerContactModel()
        {

            Name = "EMILY",
            Detail = "EMIAL@gmail.com"
        };
        public static CustomerContactModel contactModelForEmergency = new CustomerContactModel()
        {

            Name = "huba",
            Detail = "34546457"
        };
        public static CustomerContactModel contactModelForFax = new CustomerContactModel()
        {

            Name = "ghjghk",
            Detail = "36867846457"
        };
        public static CustomerContactModel contactModelForHome = new CustomerContactModel()
        {

            Name = "my home",
            Detail = "0967586768"
        };
        public static CustomerContactModel contactModelForMobile = new CustomerContactModel()
        {

            Name = "emily",
            Detail = "02278689898"
        };
        public static CustomerContactModel contactModelForWork= new CustomerContactModel()
        {

            Name = "Company",
            Detail = "097643545667"
        };
    }
}
