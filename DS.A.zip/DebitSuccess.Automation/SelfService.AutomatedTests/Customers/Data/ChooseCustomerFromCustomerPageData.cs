﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SelfService.AutomatedTests.Tests_by_whit.Model;

namespace SelfService.AutomatedTests.Tests_by_whit.Data
{
    class ChooseCustomerFromCustomerPageData
    {
        public static CustomerModel WhitCustomerModel = new CustomerModel()
        {
            
            ReferenceNumber = "WHCM888999", 
            CustomerName = WhitCustomerNameModel
        };
        public static CustomerNameModel WhitCustomerNameModel = new CustomerNameModel
        {
            FirstName = "emily",
            LastName = "li"
        };
    }
}
