﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SelfService.AutomatedTests.Tests_by_whit.Model;

namespace SelfService.AutomatedTests.Tests_by_whit.TestData
{
    public class AddressData
    {
        public static CustomerAddressModel AddressModelForPostal = new CustomerAddressModel()
        {
          
            Address1="Queen St",
            Suburb ="Auckland CBD",
            City="Auckland",
            Postcode ="1010",
            dbCountries = Country.NewZealand
        };

        public static CustomerAddressModel AddressModelForBusiness = new CustomerAddressModel()
        {

            Address1 = "Symond St",
            Suburb = "Grafton",
            City = "Auckland",
            Postcode = "1012",
            dbCountries = Country.NewZealand
        };
        public static CustomerAddressModel AddressModelForHome = new CustomerAddressModel()
        {

            Address1 = "Edward Rd",
            Suburb = "Epsom",
            City = "Auckland",
            Postcode = "1023",
            dbCountries = Country.NewZealand
        };
        public static CustomerAddressModel AddressModelForPhysical = new CustomerAddressModel()
        {

            Address1 = "5 the warehouse way",
            Suburb = "northcote",
            City = "North Shore",
            Postcode = "1000",
            dbCountries = Country.NewZealand
        };
  
    }
}
