﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SelfService.AutomatedTests.Tests_by_whit.Model;

namespace SelfService.AutomatedTests.Tests_by_whit.TestData
{
    public class CreditCardData
    {
        public class Visa : CreditCardModel
        {
            private static readonly Random RanNumGenerator = new Random();
           // private AccountType AccountType = AccountType.Creditcard;
            private string _cardNumber = "4111111111111111";

            private string _expiryMonth = RanNumGenerator.Next(1, 13).ToString();
            private string _expiryYear = RanNumGenerator.Next(16, 22).ToString();
            private CreditCardType _creditCardType = CreditCardType.Visa;
            private string _nameOnCard = "Whitney Test";

           

            public override string CardNo
            {
                get { return _cardNumber; }
                set { _cardNumber = value; }
            }

            public override string CardExpiryMonth
            {
                get
                {
                    if (int.Parse(_expiryMonth) < 10)
                    {
                        _expiryMonth = "0" + _expiryMonth;
                    }
                    return _expiryMonth;
                }
                set { _expiryMonth = value; }
            }

            public override string CardExpiryYear
            {
                get { return _expiryYear; }
                set { _expiryYear = value; }
            }

            public override CreditCardType CCType
            {
                get { return _creditCardType; }
                set { _creditCardType = value; }
            }

            public override string NameOnCard
            {
                get { return _nameOnCard; }
                set { _nameOnCard = value; }
            }
        }

        public class Mastercard : CreditCardModel
        {
            private static readonly Random RanNumGenerator = new Random();
            //private AccountType AccountType = AccountType.Creditcard;
            private string _cardNo = "5500000000000004";
            private string _expiryMonth = RanNumGenerator.Next(1, 13).ToString();
            private string _expiryYear = RanNumGenerator.Next(16, 22).ToString();
            private CreditCardType _creditCardType = CreditCardType.Mastercard;
            private string _nameOnCard = "Whitney Test";

            public override string CardNo
            {
                get { return _cardNo; }
                set { _cardNo = value; }
            }

            public override string CardExpiryMonth
            {
                get { return _expiryMonth; }
                set { _expiryMonth = value; }
            }

            public override string CardExpiryYear
            {
                get { return _expiryYear; }
                set { _expiryYear = value; }
            }
            public override CreditCardType CCType
            {
                get { return _creditCardType; }
                set { _creditCardType = value; }
            }
            public override string NameOnCard
            {
                get { return _nameOnCard; }
                set { _nameOnCard = value; }
            }
        }

        public class AmericanExpress : CreditCardModel
        {
            private static readonly Random RanNumGenerator = new Random();
            //private AccountType AccountType =AccountType.Creditcard;
            private string _cardNo = "340000000000009";
            private string _expiryMonth = RanNumGenerator.Next(10, 13).ToString();
            private string _expiryYear = RanNumGenerator.Next(16, 22).ToString();
            private CreditCardType _creditCardType = CreditCardType.AmericanExpress;
            private string _nameOnCard = "Whitney Test";


            public override string CardNo
            {
                get { return _cardNo; }
                set { _cardNo = value; }
            }

           

            public override string CardExpiryMonth
            {
                get { return _expiryMonth; }
                set { _expiryMonth = value; }
            }

            public override string CardExpiryYear
            {
                get { return _expiryYear; }
                set { _expiryYear = value; }
            }

            public override CreditCardType CCType
            {
                get { return _creditCardType; }
                set { _creditCardType = value; }
            }

            public override string NameOnCard
            {
                get { return _nameOnCard; }
                set { _nameOnCard = value; }
            }
        }

        
    }
        public enum CreditCardType
        {
            Visa,
            Mastercard,
            AmericanExpress
        }
}
