﻿namespace SelfService.AutomatedTests.Customers.Data
{
    public class CustomerData
    {
        public static string CustomerListPageTitle = "Debitsuccess - Customers";

        public static int CustomersPerPage = 10;

        public static SearchModel TestCustomer = new SearchModel
        {
            FirstName = "Kothari",
            LastName = "Priyank",
            ReferenceNumber = "DST4888240"
        };


        public static SearchModel CustomerForAddPostalAddress = new SearchModel
        {
            FirstName = "Test",
            LastName = "Account",
            ReferenceNumber = "$388899924"
        };

        public static SearchModel CustomerForEditAddress = new SearchModel
        {
            FirstName = "Deborah",
            LastName = "Agent",
            ReferenceNumber = "$388899923"
        };

        public static CustomerNameModel CustomerForUpateName = new CustomerNameModel
        {
            FirstName = "KothariUpdate",
            MiddleName = "Test Update",
            LastName = "PriyankUpdate"
        };


        public static BusinessIdModel BusinessIdForUpdate = new BusinessIdModel { BusinessId = "newid12345" };

        public static string CallNoteToAdd = "Self Service Automation Test Call Note";

        public static AddressModel NewAddress = new AddressModel
        {
            AddressType = "", //To be assigned
            Address1 = "5 Warehouse way",
            Suburb = "Northcote",
            City = "Auckland",
            Postcode = "0600",
            DbCountries = "NewZealand"
        };

        public static AddressModel UpdateAddress = new AddressModel
        {
            AddressType = "", //To be assigned 
            Address1 = "151 Queen St",
            Suburb = "CBD",
            City = "Auckland",
            Postcode = "1000",
            DbCountries = "NewZealand"
        };
    }

    public class SearchModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ReferenceNumber { get; set; }
    }

    public class CustomerNameModel
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
    }

    public class BusinessIdModel
    {
        public string BusinessId { get; set; }
    }

    public class AddressModel
    {
        public string AddressType { get; set; }
        public string Address1 { get; set; } //Street
        public string Suburb { get; set; }
        public string City { get; set; }
        public string Postcode { get; set; }
        public string AusState { get; set; }
        public string DbCountries { get; set; } //Country
    }

    public enum AddressType
    {
        Business,
        Physical,
        Home,
        Postal
    }

}
