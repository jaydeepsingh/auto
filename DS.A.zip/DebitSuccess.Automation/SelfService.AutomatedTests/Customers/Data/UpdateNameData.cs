﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SelfService.AutomatedTests.Tests_by_whit.Model;

namespace SelfService.AutomatedTests.Tests_by_whit.TestData
{
    class UpdateNameData
    {
        public static CustomerNameModel WhitCustomerModelforUpdate = new CustomerNameModel()
        {
            FirstName = "Yoki",
            MiddleName = "test",
            LastName = "Ma"
        };

//        public static CustomerNameModel WhitCustomerModelforUpdate = new CustomerNameModel()
//        {
//            FirstName = "Yoki",
//            MiddleName = "test",
//            LastName = "Ma"
//        };
//
//        public static CustomerNameModel WhitCustomerModelforUpdate = new CustomerNameModel()
//        {
//            FirstName = "Yoki",
//            MiddleName = "test",
//            LastName = "Ma"
//        };
//
//        public static CustomerNameModel WhitCustomerModelforUpdate = new CustomerNameModel()
//        {
//            FirstName = "Yoki",
//            MiddleName = "test",
//            LastName = "Ma"
//        };
    }
}
