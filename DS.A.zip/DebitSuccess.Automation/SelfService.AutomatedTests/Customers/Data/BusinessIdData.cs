﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SelfService.AutomatedTests.Tests_by_whit.Model;

namespace SelfService.AutomatedTests.Tests_by_whit.TestData
{
    public class BusinessIdData
    {
        public static BusinessIdModel WhitbBusinessIdModel= new BusinessIdModel()
        {
             BusinessId="6765677787"
        };
    }
}
