﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SelfService.AutomatedTests.Tests_by_whit.Model;

namespace SelfService.AutomatedTests.Tests_by_whit.TestData
{
    public class BankAccountData
    {
        public class BankAccount : BankAccountModel
        {
            private string _accountHolder = "Whitney Account";
            private string _bankNumber = "12";
            private string _branch = "3230";
            private string _accountNumber = "0401321";
            private string _suffix = "00";
            private string _payMethodType = "Bank account";

            public override string AccountHolder {
                get { return _accountHolder; }
                set { _accountHolder = value; } }

            public override string BankNumber
            {
                get { return _bankNumber; }
                set { _bankNumber = value; }
            }
            public override string Branch
            {
                get { return _branch; }
                set { _branch = value; }
            }
            public override string AccountNumber
            {
                get { return _accountNumber; }
                set { _accountNumber = value; }
            }
            public override string Suffix
            {
                get { return _suffix; }
                set { _suffix = value; }
            }

            public override string PayMethodType
            {
                get { return _payMethodType; }
                set { _payMethodType = value; }
            }
        }

    }
}
