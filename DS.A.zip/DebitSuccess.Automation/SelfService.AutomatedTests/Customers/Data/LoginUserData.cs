﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SelfService.AutomatedTests.Tests_by_whit.Model;

namespace SelfService.AutomatedTests.Tests_by_whit.Data
{
    class LoginUserData
    {
        public static LoginModel whitUser = new LoginModel()
        {
            CompanyId = "whit",
            UserName = "master",
            Password = "Passw0rd"
        };
    }
}
