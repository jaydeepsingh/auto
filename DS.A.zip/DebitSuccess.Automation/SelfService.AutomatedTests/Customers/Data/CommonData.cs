﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfService.AutomatedTests.Tests_by_whit.TestData
{
    public static class CommonData
    {
        public static string DateFormat = "dd/MM/yyyy";
    }
}
