﻿using System.Data;
using System.Linq;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using SelfService.AutomatedTests.Customers.Components;
using SelfService.AutomatedTests.Shared;

namespace SelfService.AutomatedTests.Customers.Pages
{
    public class CustomersListPage : SelfServiceBasePage
    {

        public CustomerSearchPanel SearchPanel
        {
            get { return GetComponent<CustomerSearchPanel>(); }
        }

        public long CustomersCount
        {
            get { return Find.Elements(By.CssSelector(".table tbody tr")).Count(); } 
        }

        public DataTable CustomersOnPage
        {
            get
            {
                return Find.Table();
            }
        }

        public CustomerDetailsPage SelectCustomerByReferenceNumber(string referenceNo)
        {
            return Navigate.To<CustomerDetailsPage>(By.LinkText(referenceNo));
        }

    }
}
