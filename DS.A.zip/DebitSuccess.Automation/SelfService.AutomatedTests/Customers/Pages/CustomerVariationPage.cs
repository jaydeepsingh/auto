﻿using System.Data;
using DebitSuccess.Automation.Framework.Extensions;
using DebitSuccess.Automation.Framework.Utilities;
using OpenQA.Selenium;
using SelfService.AutomatedTests.Customers.Data;
using SelfService.AutomatedTests.Shared;

namespace SelfService.AutomatedTests.Customers.Pages
{
    public class CustomerVariationPage : SelfServiceBasePage
    {
        public UpdateCustomerPage UpdateCustomerTab { get { return Navigate.To<UpdateCustomerPage>(By.LinkText("Update Name")); } }

        public BusinessIdPage BusinessIdTab { get { return Navigate.To<BusinessIdPage>(By.LinkText("Business ID")); } }

        public AddressesPage AddressesTab { get { return Navigate.To<AddressesPage>(By.LinkText("Addresses")); } }

        public AddCallNotePage AddCallNoteTab { get { return Navigate.To<AddCallNotePage>(By.LinkText("Add Call Note")); } }
    }

    public class UpdateCustomerPage : SelfServiceBasePage
    {
        public CustomerNameModel Customer
        {
            get { return Find.ModelFromPage<CustomerNameModel>(); }
        }


        public CustomerVariationPage UpdateCustomerName(CustomerNameModel customerModel)
        {
            Find.SendModelToPage(new
            {
                customerModel.FirstName,
                customerModel.MiddleName,
                customerModel.LastName
            });

            return Navigate.To<CustomerVariationPage>(By.Id("btnUpdate"));
        }
    }

    public class BusinessIdPage : SelfServiceBasePage
    {
        public BusinessIdModel UpdatedBusinessId
        {
            get { return Find.ModelFromPage<BusinessIdModel>(); }
        }


        public CustomerVariationPage UpdateBusinessId(BusinessIdModel businessId)
        {
            Find.SendModelToPage(businessId);
            return Navigate.To<CustomerVariationPage>(By.Id("btnUpdate"));
        }
    }

    public class AddCallNotePage : SelfServiceBasePage
    {
        public string CallNote { set { Find.Element(By.Id("Detail")).ClearAndSendKey(value);} }

        public CustomerVariationPage AddNote(string callNote)
        {
            WaitFor.AjaxCallsToComplete();

            CallNote = callNote;

            return Navigate.To<CustomerVariationPage>(By.Id("btnAdd"));
        }
    }

    public class AddressesPage : SelfServiceBasePage
    {
        public string Country
        {
            set { Find.Element(By.Id("dbCountries")).SetControlValue(value); }
        }

        public bool IsStateVisible
        {
            get { return Execute.ScriptAndReturn<bool>("$('#AusState').is(':visible')"); }
        }

        public DataTable AddressesOnPage
        {
            get
            {
                return Find.Table();
            }
        }

        public AddressesPage GoAddAddress()
        {
            return Navigate.To<AddressesPage>(By.LinkText("Add address"));
        }

        public AddressesPage GoEditAddress(AddressType type)
        {
            return Navigate.To<AddressesPage>(By.XPath(XPathLibrary.ButtonOnRowWithText(type.ToString(), "Edit")));
        }


        public CustomerVariationPage AddAddress(AddressModel model)
        {
            Find.SendModelToPage(model);
            return Navigate.To<CustomerVariationPage>(By.Id("btnAdd"));
        }

        public CustomerVariationPage EditAddress(AddressModel model, params string[] skipProperties)
        {
            Find.SendModelToPage(model, skipProperties);
            return Navigate.To<CustomerVariationPage>(By.Id("btnUpdate"));
        }
    }
}
