﻿using System.Collections.Generic;
using System.Threading;
using DebitSuccess.Automation.Framework.Extensions;
using OpenQA.Selenium;
using SelfService.AutomatedTests.Shared;

namespace SelfService.AutomatedTests.Customers.Pages
{
    public class CustomerDetailsPage : SelfServiceBasePage
    {
        public CustomerVariationPage VariationTab
        {
            get
            {
                return Navigate.To<CustomerVariationPage>(By.LinkText("Variations"));
            }
        }

        public CallHistoryPage CallHistoryTab
        {
            get
            {
                return Navigate.To<CallHistoryPage>(By.LinkText("Call History"));
            }
        }
    }

    public class CallHistoryPage : SelfServiceBasePage
    {
        public List<string> LastCallNote
        {
            get
            {
                return Find.FirstRow();
            }
        }
    }
}
