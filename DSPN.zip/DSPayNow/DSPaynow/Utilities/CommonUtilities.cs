﻿using OpenQA.Selenium;
using System;

namespace DSPaynow.Utilities
{
    public class CommonUtilities
    {
        public static readonly log4net.ILog log =
                        log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static void Click(IWebElement webElement)
                {
                     webElement.Click();
                }

        public static void TakeScreenshot(String methodName)
        {
            try
            {
                
                Screenshot ss = ((ITakesScreenshot)Driver.driver).GetScreenshot();
                //ss.SaveAsFile(@"C:\Jaydeep\Projects\QA Automation\DSPayNow\DSPaynow\Screenshots\"+ methodName + ".jpg", ScreenshotImageFormat.Jpeg);
                ss.SaveAsFile(@"D:\AutomationResults\Paynow\screenshots\" + methodName + ".jpg", ScreenshotImageFormat.Jpeg);
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }

    }



}
