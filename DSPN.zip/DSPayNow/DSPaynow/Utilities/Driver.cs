﻿using DSPaynow.TestDataAccess;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPaynow.Utilities
{
    public class Driver
    {
       public static IWebDriver driver ;
        public static void InitializeDriver(String browser)
        {
            if(browser.ToLower() == "chrome")
            {
               driver = new ChromeDriver();
            }else if(browser.ToLower() == ("firefox"))
            {
                driver = new FirefoxDriver();
            }
            else if (browser.ToLower() == "ie")
            {
                driver = new InternetExplorerDriver();
            }

        }

        public static void GetURL()
        {
            try
            {
                //var userData = ExcelDataAccess.GetTestData("URL");
                //driver.Url = userData.Value;
                driver.Url = TestData.url;
                driver.Manage().Timeouts().ImplicitWait= TimeSpan.FromSeconds(20);
                driver.Manage().Window.Maximize();
            }
            catch(Exception e){
                Console.WriteLine("You did not enter the URL correctly");
                throw (e);
            }
        }

    }

  

    
}
