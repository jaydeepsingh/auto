﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPaynow.TestDataAccess
{
    public class TestData
    {

        


        public static string url = "https://oc-dev.debitsuccess.com/DsToken/";
        public static string adfitNo = "TST4888973";
        public static string externalRefNo = "";
        public static Boolean createOneOffCharge = true;
        public static string paymentNotes = "TestNotes";
        public static string paymentMethodType = "Credit Card";
        //public static string requestType = "Update Payment Details";
        public static string name = "Tester";
        public static string cardNumber = "4111111111111111";
        public static string amount = "5";
        public static string validToMonth = "01";
        public static string validToYear = "2018";
        public static string cVC = "123";
        public static string email = "abc@xyz.com";
        public static string callbackURL = "http://www.google.com";


        

    }
}
