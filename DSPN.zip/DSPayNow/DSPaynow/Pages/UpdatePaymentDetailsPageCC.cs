﻿using DSPaynow.TestDataAccess;
using DSPaynow.Utilities;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPaynow.Pages
{
    class UpdatePaymentDetailsPageCC
    {

        public static void EnterCardHolderName()
        {
            //Enter Name
            try
            {
                //var userData = ExcelDataAccess.GetTestData("Name");
                Driver.driver.FindElement(By.XPath("//*[@id='CcHolderName']")).SendKeys(TestData.name);
                CommonUtilities.log.Info("Entered Name");
            }
            catch(Exception e){
                CommonUtilities.log.Error("Couldn't enter Name", e);
                CommonUtilities.TakeScreenshot("EnterCardHolderName");
                //throw (e);
            }
}

        public static void EnterCardNumber()
        {
            //Enter card Number
            try
            {
                //var userData = ExcelDataAccess.GetTestData("CardNumber");
                Driver.driver.FindElement(By.XPath("//*[@id='CreditCardNumber']")).SendKeys(TestData.cardNumber);
                CommonUtilities.log.Info("Entered ValidToMonth");
            }
            catch(Exception e){
                CommonUtilities.log.Error("Couldn't enter ValidToMonth", e);
                CommonUtilities.TakeScreenshot("EnterCardNumber");
                //throw (e);
            }
}

        public static void SelectValidToMonth()
        {
            //Enter month
            try
            {
                //var userData = ExcelDataAccess.GetTestData("ValidToMonth");
                SelectElement validToMonth = new SelectElement(Driver.driver.FindElement(By.XPath("//*[@id='ExpiryMonth']")));
                validToMonth.SelectByValue(TestData.validToMonth);
                CommonUtilities.log.Info("Entered ValidToMonth");
            }
            catch(Exception e){
                CommonUtilities.log.Error("Couldn't enter ValidToMonth", e);
                CommonUtilities.TakeScreenshot("SelectValidToMonth");
                //throw (e);
            }
}

        public static void SelectValidToYear()
        {
            //Enter year
            try
            {
                //var userData = ExcelDataAccess.GetTestData("ValidToYear");
                SelectElement validToYear = new SelectElement(Driver.driver.FindElement(By.XPath("//*[@id='ExpiryYear']")));
                validToYear.SelectByValue(TestData.validToYear);
                CommonUtilities.log.Info("Entered ValidToYear");
            }
            catch(Exception e){
                CommonUtilities.log.Error("Couldn't enter ValidToYear", e);
                CommonUtilities.TakeScreenshot("SelectValidToYear");
                //throw (e);
            }
}

        public static void EnterEmail()
        {
            //Enter email
            try
            {
                //var userData = ExcelDataAccess.GetTestData("Email");
                Driver.driver.FindElement(By.XPath("//*[@id='ReceiptEmailAddress']")).SendKeys(TestData.email);
                CommonUtilities.log.Info("Entered Email");
            }
            catch(Exception e){
                CommonUtilities.log.Error("Couldn't enter Email", e);
                CommonUtilities.TakeScreenshot("EnterEmail");
                //throw (e);
            }
}
        public static void CheckAuthorityBox()
        {
            //Enter email
            try
            {

                Driver.driver.FindElement(By.XPath("//*[@id='DebitAuthorization']")).Click();
                CommonUtilities.log.Info("Checked AuthorityBox");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't Check AuthorityBox", e);
                CommonUtilities.TakeScreenshot("CheckAuthorityBox");
                //throw (e);
            }
        }

        public static void ClickAddDetailsButton()
        {
            //Click Add Details button
            try
            {
                Driver.driver.FindElement(By.XPath("//*[@id='submit--update__cc']")).Click();
                CommonUtilities.log.Info("Clicked AddDetailsButton");
            }
            catch(Exception e){
                CommonUtilities.log.Error("Couldn't Click AddDetailsButton", e);
                CommonUtilities.TakeScreenshot("ClickAddDetailsButton");
                //throw (e);
            }
}

        public static void ClickConfirmButton()
        {
            //Click confirm button
            try
            {
                Driver.driver.FindElement(By.XPath("//*[@id='redirect-link']")).Click();
                CommonUtilities.log.Info("Clicked Confirm Button");
            }
            catch(Exception e){
                CommonUtilities.log.Error("Couldn't Click Confirm Button", e);
                CommonUtilities.TakeScreenshot("ClickConfirmButton");
                //throw (e);
            }



}

        //public static void EnterName(String name)
        //{
        //    //Enter Name
        //    try
        //    {
        //        Driver.driver.FindElement(By.XPath("//*[@id='CcHolderName']")).SendKeys(name);
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine("Couldnt find CcHolderName element on UpdatePaymentDetailsPage");
        //        throw (e);
        //    }
        //}


    }
}
