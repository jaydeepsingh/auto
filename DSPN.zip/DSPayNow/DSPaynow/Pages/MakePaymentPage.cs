﻿using DSPaynow.TestDataAccess;
using DSPaynow.Utilities;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Threading;

namespace DSPaynow.Pages
{
    class MakePaymentPage
    {

        public static void ClickMakePayamentUsingExistingCCButton()
        {

            try
            {
                Driver.driver.FindElement(By.XPath("//*[@id='form']/div[2]/label[1]")).Click();
                CommonUtilities.log.Info("Clicked MakePayamentUsingExistingCCButton");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't click MakePayamentUsingExistingCCButton", e);
                CommonUtilities.TakeScreenshot("ClickMakePayamentUsingExistingCCButton");
                //throw (e);
            }

        }

        public static void ClickMakePayamentUsingNewCCButton()
        {

            try
            {
                Driver.driver.FindElement(By.XPath("//*[@id='form']/div[2]/label[2]")).Click();
                CommonUtilities.log.Info("Clicked MakePayamentUsingNewCCButton");

            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't click MakePayamentUsingNewCCButton", e);
                CommonUtilities.TakeScreenshot("ClickMakePayamentUsingNewCCButton");
                //throw (e);
            }

        }

        public static void ClickRadioButtonForCard()
        {

            try
            {
                Driver.driver.FindElement(By.XPath("//*[@id='SelectedCreditCardId']")).Click();
                CommonUtilities.log.Info("Clicked RadioButtonForCard");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't click RadioButtonForCard", e);
                CommonUtilities.TakeScreenshot("ClickRadioButtonForCard");
                //throw (e);
            }

        }



        public static void EnterName()
        {
            //Enter Name
            try
            {
                //var userData = ExcelDataAccess.GetTestData("Name");
                Driver.driver.FindElement(By.XPath("//*[@id='CcHolderName']")).SendKeys(TestData.name);
                CommonUtilities.log.Info("Entered Name");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't  Enter Name", e);
                CommonUtilities.TakeScreenshot("EnterName");
                //throw (e);
            }
        }

        public static void EnterCardNumber()
        {
            //Enter card Number
            try
            {
                //var userData = ExcelDataAccess.GetTestData("CardNumber");
                Driver.driver.FindElement(By.XPath("//*[@id='CreditCardNumber']")).SendKeys(TestData.cardNumber);
                CommonUtilities.log.Info("Entered CardNumber");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't  Enter CardNumber", e);
                CommonUtilities.TakeScreenshot("EnterCardNumber");
                //throw (e);
            }
        }

        public static void SelectValidToMonth()
        {
            //Enter month
            try
            {
                //var userData = ExcelDataAccess.GetTestData("ValidToMonth");
                SelectElement expiryMonth = new SelectElement(Driver.driver.FindElement(By.XPath("//*[@id='ExpiryMonth']")));
                expiryMonth.SelectByValue(TestData.validToMonth);
                CommonUtilities.log.Info("Entered ValidToMonth");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't  Enter ValidToMonth", e);
                CommonUtilities.TakeScreenshot("SelectValidToMonth");
                //throw (e);
            }
        }

        public static void SelectValidToYear()
        {
            //Enter year
            try
            {
                //var userData = ExcelDataAccess.GetTestData("ValidToYear");
                SelectElement expiryYear = new SelectElement(Driver.driver.FindElement(By.XPath("//*[@id='ExpiryYear']")));
                expiryYear.SelectByValue(TestData.validToYear);
                CommonUtilities.log.Info("Entered ValidToYear");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't  Enter ValidToYear", e);
                CommonUtilities.TakeScreenshot("SelectValidToYear");
                //throw (e);
            }
        }


        public static void EnterCVC()
        {
            //Enter cvc
            try
            {
                //var userData = ExcelDataAccess.GetTestData("CVC");
                Driver.driver.FindElement(By.XPath("//*[@id='Cvc']")).SendKeys(TestData.cVC);
                CommonUtilities.log.Info("Entered CVC");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't  Enter CVC", e);
                CommonUtilities.TakeScreenshot("EnterCVC");
                //throw (e);
            }
        }

        public static void EnterEmail()
        {
            //Enter email
            try
            {
                //var userData = ExcelDataAccess.GetTestData("Email");
                Driver.driver.FindElement(By.XPath("//*[@id='ReceiptEmailAddress']")).SendKeys(TestData.email);
                CommonUtilities.log.Info("Entered Email");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't  Enter Email", e);
                CommonUtilities.TakeScreenshot("EnterEmail");
                //throw (e);
            }
        }

        public static void ClickNextButton()
        {
            //click Next
            try
            {
                IWebElement nextButton = Driver.driver.FindElement(By.XPath("//*[@id='sb']"));
                IJavaScriptExecutor js = (IJavaScriptExecutor)Driver.driver;
                js.ExecuteScript("arguments[0].scrollIntoView(true);", nextButton);
                nextButton.Click();
                Thread.Sleep(500);
                CommonUtilities.log.Info("Clicked NextButton");
                CommonUtilities.TakeScreenshot("PaymentReviewPage");

            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't  Click NextButton", e);
                CommonUtilities.TakeScreenshot("PaymentDetailsPage");
                //throw (e);
            }

        }

        public static void ClickPayNowButton()
        {
            //click Next
            try
            {
                IWebElement nextButton = Driver.driver.FindElement(By.XPath("//*[@id='sb']"));
                IJavaScriptExecutor js = (IJavaScriptExecutor)Driver.driver;
                js.ExecuteScript("arguments[0].scrollIntoView(true);", nextButton);
                nextButton.Click();
                Thread.Sleep(500);
                CommonUtilities.log.Info("Clicked PayNow Button");
                CommonUtilities.TakeScreenshot("PaymentAuthorizedPage");

            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't  Click NextButton", e);
                CommonUtilities.TakeScreenshot("PaymentReviewPage");
                //throw (e);
            }

        }



    }
}
