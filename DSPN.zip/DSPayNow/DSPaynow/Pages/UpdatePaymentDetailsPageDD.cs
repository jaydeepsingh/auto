﻿using DSPaynow.TestDataAccess;
using DSPaynow.Utilities;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPaynow.Pages
{
    class UpdatePaymentDetailsPageDD
    {

        public static void EnterAccountHolderName()
        {
            //Enter Name
            try
            {
                //var userData = ExcelDataAccess.GetTestData("Name");
                Driver.driver.FindElement(By.XPath("//*[@id='AccountHolderName']")).SendKeys(TestData.name);
                CommonUtilities.log.Info("Entered Name");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't enter Name", e);
                CommonUtilities.TakeScreenshot("EnterAccountHolderName");
                //throw (e);
            }
        }

        public static void EnterNZAccountNumber()
        {
            //Enter card Number
            try
            {
                //var userData = ExcelDataAccess.GetTestData("CardNumber");
                Driver.driver.FindElement(By.XPath("//*[@id='NzAccountNumber']")).SendKeys(TestData.cardNumber);
                CommonUtilities.log.Info("Entered ValidToMonth");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't enter ValidToMonth", e);
                CommonUtilities.TakeScreenshot("EnterNZAccountNumber");
                //throw (e);
            }
        }

        public static void EnterEmail()
        {
            //Enter email
            try
            {
                //var userData = ExcelDataAccess.GetTestData("Email");
                Driver.driver.FindElement(By.XPath("//*[@id='ReceiptEmailAddress']")).SendKeys(TestData.email);
                CommonUtilities.log.Info("Entered Email");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't enter Email", e);
                CommonUtilities.TakeScreenshot("EnterEmail");
                //throw (e);
            }
        }
    }
}
