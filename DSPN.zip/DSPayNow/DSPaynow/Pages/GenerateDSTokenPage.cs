﻿using DSPaynow.TestDataAccess;
using DSPaynow.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPaynow.Pages
{
    public class GenerateDSTokenPage
    {
        //public static IWebDriver driver;
        // SetupandTearDown std = new SetupandTearDown();
        public static void EnterAdfitNo()
        {
            //Enter AdfitNo
            try
            {
                //var userData = ExcelDataAccess.GetTestData("AdfitNo");
                Driver.driver.FindElement(By.XPath("//*[@id='AdfitNo']")).SendKeys(TestData.adfitNo);
                CommonUtilities.log.Info("Entered AdfitNo");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't enter AdfitNo", e);
                CommonUtilities.TakeScreenshot("EnterAdfitNo");
                //throw (e);
            }
        }

        public static void EnterExternalRefNo(String externalRefNo)
        {
            //Enter ExtRefNo
            try
            {
                //var userData = ExcelDataAccess.GetTestData(externalRefNo);
                Driver.driver.FindElement(By.XPath("//*[@id='ClubNo']")).SendKeys(TestData.externalRefNo);
                CommonUtilities.log.Info("Entered ExternalRefNo");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't enter ExternalRefNo", e);
                CommonUtilities.TakeScreenshot("EnterExternalRefNo");
                //throw (e);
            }
        }

        public static void EnterPaymentNotes()
        {
            //Enter Payment Notes
            try
            {
                //var userData = ExcelDataAccess.GetTestData("PaymentNotes");
                Driver.driver.FindElement(By.XPath("//*[@id='PaymentNote']")).SendKeys(TestData.paymentNotes);
                CommonUtilities.log.Info("Entered PaymentNotes");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't enter PaymentNotes", e);
                CommonUtilities.TakeScreenshot("EnterPaymentNotes");
                //throw (e);
            }
        }

        public static void EnterCallbackURL()
        {
            //Enter Callback URL
            try
            {
                //var userData = ExcelDataAccess.GetTestData("CallbackURL");
                Driver.driver.FindElement(By.XPath("//*[@id='PayNowCallBackUrl']")).SendKeys(TestData.callbackURL);
                CommonUtilities.log.Info("Entered CallbackURL");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't enter CallbackURL", e);
                CommonUtilities.TakeScreenshot("EnterCallbackURL");
                //throw (e);
            }
        }

        public static void SelectPaymentMethodType()
        {
            //Select Payment method type
            try
            {
                //var userData = ExcelDataAccess.GetTestData("PaymentMethodType");
                SelectElement paymentType = new SelectElement(Driver.driver.FindElement(By.XPath("//*[@id='PayMethodType']")));
                CommonUtilities.log.Info("Entered PaymentMethodType");
                paymentType.SelectByText(TestData.paymentMethodType);
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't enter PaymentMethodType", e);
                CommonUtilities.TakeScreenshot("SelectPaymentMethodType");
                //throw (e);
            }
        }

        public static void SelectRequestType(String requestType)
        {
            //Select Request type
            try
            {
                SelectElement reqType = new SelectElement(Driver.driver.FindElement(By.XPath("//*[@id='PayNowRequestType']")));
                CommonUtilities.log.Info("Selected requestType");
                reqType.SelectByText(requestType);
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't select requestType", e);
                CommonUtilities.TakeScreenshot("SelectRequestType");
                //throw (e);
            }
        }

        public static void EnterAmount()
        {
            //Enter Amount
            try
            {
                //var userData = ExcelDataAccess.GetTestData("Amount");
                Driver.driver.FindElement(By.XPath("//*[@id='Amount']")).SendKeys(TestData.amount);
                CommonUtilities.log.Info("Entered Amount");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't enter Amount", e);
                CommonUtilities.TakeScreenshot("EnterAmount");
                //throw (e);
            }
        }

        public static void CheckCreateOneOffCharge(bool checkCreateOneOffCharge)
        {

            //Checkbox Create one-off charge
            try
            {
                // var userData = ExcelDataAccess.GetTestData(externalRefNo);
                if (checkCreateOneOffCharge == true)
                {
                    Driver.driver.FindElement(By.XPath("//*[@id='CreateOneOffCharge']")).Click();
                    CommonUtilities.log.Info("Checked Onoff charge");
                    CommonUtilities.TakeScreenshot("CheckCreateOneOffCharge");
                }
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't check Onoff charge", e);
                CommonUtilities.TakeScreenshot("CheckCreateOneOffCharge");
                //throw (e);
            }
        }



        public static void ClickButtonGenerateToken()
        {
            //click button to generate token
            try
            {
                Driver.driver.FindElement(By.XPath("//*[@id='form--generate-token']/div[5]/div/button")).Click();
                CommonUtilities.log.Info("Clicked ButtonGenerateToken");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't Click ButtonGenerateToken", e);
                CommonUtilities.TakeScreenshot("ClickButtonGenerateToken");
                //throw (e);
            }

        }



        public static void ClickTokenLink()
        {
            //click token link
            try
            {
                Driver.driver.FindElement(By.XPath("//*[contains(@class, 'link--redirect-to-payment')]")).Click();
                CommonUtilities.log.Info("Clicked TokenLink");
            }
            catch (Exception e)
            {
                CommonUtilities.log.Error("Couldn't click on TokenLink", e);
                CommonUtilities.TakeScreenshot("ClickTokenLink");
                //throw (e);
            }
        }



    }
}
