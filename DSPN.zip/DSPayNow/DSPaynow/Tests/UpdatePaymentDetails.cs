﻿using DSPaynow.Pages;
using DSPaynow.Utilities;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPaynow.Tests
{
    class UpdatePaymentDetails
    {
        [SetUp]
        public void Initialize()
        {
            Driver.InitializeDriver("chrome");
            Driver.GetURL();
            GenerateToken token = new GenerateToken();
            token.GenerateDSTokenToUpdatePaymentDetails();

        }

        [Test]
        public void UpdatePaymentDetailsCC()
        {
                        
            //Enter Name

            UpdatePaymentDetailsPageCC.EnterCardHolderName();

            //Enter card number
            UpdatePaymentDetailsPageCC.EnterCardNumber();

            //Enter 'valid to' month and year
            UpdatePaymentDetailsPageCC.SelectValidToMonth();
            UpdatePaymentDetailsPageCC.SelectValidToYear();

            //Enter Email
            UpdatePaymentDetailsPageCC.EnterEmail();

            //Click Add Details
            UpdatePaymentDetailsPageCC.ClickAddDetailsButton();

            //Click confirm
            UpdatePaymentDetailsPageCC.ClickConfirmButton();

            Assert.AreEqual(Driver.driver.Url, "https://oc-qa.debitsuccess.com/PayNow/Pay");

        }

        [TearDown]
        public void EndTest()
        {
           Driver.driver.Close();
           Driver.driver.Quit();
        }

    }
}
