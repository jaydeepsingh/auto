﻿using DSPaynow.Pages;
using DSPaynow.Utilities;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPaynow.Tests
{
    class MakePaymentUsingNewCard
    {

        [SetUp]
        public void Initialize()
        {
            Driver.InitializeDriver("chrome");
            Driver.GetURL();
            GenerateToken token = new GenerateToken();
            token.GenerateDSTokenToMakePayment();
            
        }

        [Test]
        //[Ignore("Ignoring making a payment")]
        public void MakePaymentWithNewCard()
        {
            //check if any existing credit card exists
            if (Driver.driver.PageSource.Contains("Make payment using new credit card"))
            {
                MakePaymentPage.ClickMakePayamentUsingNewCCButton();

                //Enter Name
                MakePaymentPage.EnterName();

                //Enter card number
                MakePaymentPage.EnterCardNumber();

                //Enter 'valid to' month and year
                MakePaymentPage.SelectValidToMonth();
                MakePaymentPage.SelectValidToYear();

                //Enter CVC
                MakePaymentPage.EnterCVC();

                //Enter Email
                MakePaymentPage.EnterEmail();

                //Click Next Button
                MakePaymentPage.ClickNextButton();
             
                Assert.AreEqual(Driver.driver.Url, "https://oc-qa.debitsuccess.com/PayNow/Pay");

                //Click Paynow Button
                MakePaymentPage.ClickPayNowButton();

                Assert.AreEqual(Driver.driver.Url, "https://oc-qa.debitsuccess.com/PayNow/Pay/Authorised");
            }

            

        }

        [TearDown]
        public void EndTest()
        {
          Driver.driver.Close();
          Driver.driver.Quit();
        }
    }
}
