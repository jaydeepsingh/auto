﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPaynow.Utilities;
using DSPaynow.Pages;
using System.Diagnostics;

namespace DSPaynow.Tests
{
    class GenerateToken
    {

        [SetUp]
        public void Initialize()
        {
            Driver.InitializeDriver("chrome");
            Driver.GetURL();
            Driver.driver.Manage().Window.Maximize();
        }

        [Test]
        public void GenerateDSTokenToUpdatePaymentDetails()
        {
            CommonUtilities.TakeScreenshot("GenerateDSTokenToUpdatePaymentDetails");

            //Enter AdfitNo
            GenerateDSTokenPage.EnterAdfitNo();
            
            //Enter ExtRefNo
            GenerateDSTokenPage.EnterExternalRefNo("");

            //Enter Payment Notes
            GenerateDSTokenPage.EnterPaymentNotes();

            //Enter Callback URL
            GenerateDSTokenPage.EnterCallbackURL();

            //Select Payment method type
            GenerateDSTokenPage.SelectPaymentMethodType();

            //Select Request type
            GenerateDSTokenPage.SelectRequestType("Update Payment Details");

            //Enter Amount
            GenerateDSTokenPage.EnterAmount();

            //Button Generate Token
            GenerateDSTokenPage.ClickButtonGenerateToken();

            //Click token link
            GenerateDSTokenPage.ClickTokenLink();

            //Verify if the token is generated correctly
            Assert.AreEqual(Driver.driver.Url, "https://oc-qa.debitsuccess.com/PayNow/Update");

            
        }

        [Test]
        //[Ignore("")]
        public void GenerateDSTokenToMakePayment()
        {


            //Enter AdfitNo
            GenerateDSTokenPage.EnterAdfitNo();
                    
            //Enter ExtRefNo
            GenerateDSTokenPage.EnterExternalRefNo("");

            //Enter Payment Notes
            GenerateDSTokenPage.EnterPaymentNotes();

            //Enter Callback URL
            GenerateDSTokenPage.EnterCallbackURL();

            //Select Payment method type
            GenerateDSTokenPage.SelectPaymentMethodType();

            //Select Request type
            GenerateDSTokenPage.SelectRequestType("Real-time Payment");

            //Enter Amount
            GenerateDSTokenPage.EnterAmount();

            //Checkbox Create one-off charge
            GenerateDSTokenPage.CheckCreateOneOffCharge(false);

            //Button Generate Token
            GenerateDSTokenPage.ClickButtonGenerateToken();

            //Click token link
            GenerateDSTokenPage.ClickTokenLink();

            //Verify if the token is generated correctly
            Assert.AreEqual(Driver.driver.Url, "https://oc-qa.debitsuccess.com/PayNow/Card");
           
        }

        

        [TearDown]
        public void EndTest()
        {
            Driver.driver.Close();
            Driver.driver.Quit();
        }


    }
}
