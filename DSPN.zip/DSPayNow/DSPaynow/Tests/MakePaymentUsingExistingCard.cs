﻿using DSPaynow.Pages;
using DSPaynow.Utilities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPaynow.Tests
{
    class MakePaymentUsingExistingCard
    {

        [SetUp]
        public void Initialize()
        {
            Driver.InitializeDriver("chrome");
            Driver.GetURL();
            GenerateToken token = new GenerateToken();
            token.GenerateDSTokenToMakePayment();

        }

        [Test]
        //[Ignore("Ignoring making a payment")]
        public void MakePaymentWithExistingCard()
        {
            //check if any existing credit card exists
            if (Driver.driver.PageSource.Contains("Make payment using existing credit card"))
            {

                //Select first card in the list 
                MakePaymentPage.ClickRadioButtonForCard();

                //Enter CVC
                MakePaymentPage.EnterCVC();

                //Enter Email
                MakePaymentPage.EnterEmail();

                //Click Next Button
                MakePaymentPage.ClickNextButton();

                Assert.AreEqual(Driver.driver.Url, "https://oc-qa.debitsuccess.com/PayNow/Pay");

                //Click Paynow Button
                MakePaymentPage.ClickPayNowButton();

                Assert.AreEqual(Driver.driver.Url, "https://oc-qa.debitsuccess.com/PayNow/Pay/Authorised");
            
            }

           

        }

        [TearDown]
        public void EndTest()
        {
            Driver.driver.Close();
            Driver.driver.Quit();
        }
    
}
}
